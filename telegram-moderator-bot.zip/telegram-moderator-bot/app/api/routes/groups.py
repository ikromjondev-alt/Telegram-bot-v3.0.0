"""
Список подключённых групп, отключение группы от модерации, чтение/изменение
индивидуальных настроек модерации группы.

Добавление группы происходит только через сам Telegram (бота добавляют
в группу) — см. app.bot.handlers.group_management. Панель может группу
только отобразить и отключить.
"""

from __future__ import annotations

from aiohttp import web

from app.api.responses import error, ok
from app.core.exceptions import AppError, ForbiddenError, ValidationAppError
from app.repositories.group_repository import GroupRepository
from app.services.group_service import GroupService

routes = web.RouteTableDef()

_SETTINGS_FIELDS = (
    "mute_duration_minutes",
    "warn_limit",
    "flood_limit",
    "flood_window_seconds",
    "auto_delete_service_messages",
    "antispam_enabled",
    "antiflood_enabled",
    "logs_enabled",
    "notifications_enabled",
    "language",
)


@routes.get("/api/groups")
async def list_groups(request: web.Request) -> web.Response:
    groups = await GroupRepository(request["session"]).list_active()
    return ok(
        [
            {
                "chat_id": g.chat_id,
                "title": g.title,
                "username": g.username,
                "members_count": g.members_count,
                "is_active": g.is_active,
                "created_at": g.created_at.isoformat(),
            }
            for g in groups
        ]
    )


@routes.get("/api/groups/{chat_id}")
async def get_group(request: web.Request) -> web.Response:
    try:
        chat_id = int(request.match_info["chat_id"])
    except ValueError:
        raise ValidationAppError("chat_id должен быть числом")

    group = await GroupRepository(request["session"]).get_by_chat_id(chat_id, with_settings=True)
    if group is None:
        return error("not_found", "Группа не найдена", status=404)

    s = group.settings
    return ok(
        {
            "chat_id": group.chat_id,
            "title": group.title,
            "username": group.username,
            "members_count": group.members_count,
            "is_active": group.is_active,
            "settings": {field: getattr(s, field) for field in _SETTINGS_FIELDS},
        }
    )


@routes.patch("/api/groups/{chat_id}/settings")
async def update_group_settings(request: web.Request) -> web.Response:
    admin = request["current_admin"]
    if not admin.can_edit_settings():
        raise ForbiddenError("Недостаточно прав для изменения настроек")

    try:
        chat_id = int(request.match_info["chat_id"])
    except ValueError:
        raise ValidationAppError("chat_id должен быть числом")

    body = await request.json()
    fields = {key: body[key] for key in _SETTINGS_FIELDS if key in body}
    if not fields:
        raise ValidationAppError("Не передано ни одного поля настроек")

    if "language" in fields and fields["language"] not in ("ru", "uz"):
        raise ValidationAppError("language должен быть 'ru' или 'uz'")

    repo = GroupRepository(request["session"])
    group = await repo.get_by_chat_id(chat_id, with_settings=True)
    if group is None:
        return error("not_found", "Группа не найдена", status=404)

    settings = await repo.update_settings(group, **fields)
    return ok({field: getattr(settings, field) for field in _SETTINGS_FIELDS})


@routes.delete("/api/groups/{chat_id}")
async def disconnect_group(request: web.Request) -> web.Response:
    try:
        chat_id = int(request.match_info["chat_id"])
    except ValueError:
        raise ValidationAppError("chat_id должен быть числом")

    actor = request["current_admin"]
    service = GroupService(request["session"])

    try:
        await service.disconnect_group(chat_id=chat_id, actor_id=actor.telegram_id)
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    try:
        await request.app["bot"].leave_chat(chat_id)
    except Exception:  # noqa: BLE001 — бот может быть уже удалён из группы вручную
        pass

    return ok({"message": "Группа отключена от модерации"})
