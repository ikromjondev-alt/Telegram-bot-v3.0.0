"""
GET /api/dashboard — все данные главной страницы панели:
группы, пользователи, удалённые сообщения, варны/муты/баны/кики,
последняя активность, онлайн-статус бота, RAM/CPU, ping, uptime.
"""

from __future__ import annotations

import time

import psutil
from aiohttp import web

from app.api.responses import ok
from app.repositories.group_repository import GroupRepository
from app.repositories.moderation_repository import ModerationRepository
from app.repositories.user_repository import UserRepository

routes = web.RouteTableDef()

_process = psutil.Process()


async def _measure_ping_ms(bot) -> float:
    start = time.perf_counter()
    await bot.get_me()
    return round((time.perf_counter() - start) * 1000, 1)


@routes.get("/api/dashboard")
async def get_dashboard(request: web.Request) -> web.Response:
    session = request["session"]
    bot = request.app["bot"]
    started_at: float = request.app["started_at"]

    groups_count = await GroupRepository(session).count_active()
    users_count = await UserRepository(session).count()
    counters = await ModerationRepository(session).dashboard_counters()
    recent_actions = await ModerationRepository(session).list_recent(limit=10)

    bot_online = True
    ping_ms: float | None = None
    try:
        ping_ms = await _measure_ping_ms(bot)
    except Exception:  # noqa: BLE001
        bot_online = False

    memory_info = _process.memory_info()

    last_activity = None
    if recent_actions:
        last = recent_actions[0]
        last_activity = {
            "action_type": last.action_type.value,
            "target_user_id": last.target_user_id,
            "group_id": last.group_id,
            "created_at": last.created_at.isoformat(),
        }

    return ok(
        {
            "groups_count": groups_count,
            "users_count": users_count,
            "deleted_messages_count": counters["deleted_messages"],
            "warns_count": counters["warns"],
            "mutes_count": counters["mutes"],
            "bans_count": counters["bans"],
            "kicks_count": counters["kicks"],
            "last_activity": last_activity,
            "bot": {
                "online": bot_online,
                "ping_ms": ping_ms,
                "uptime_seconds": round(time.monotonic() - started_at),
                "ram_mb": round(memory_info.rss / (1024 * 1024), 1),
                "cpu_percent": _process.cpu_percent(interval=0.1),
            },
        }
    )
