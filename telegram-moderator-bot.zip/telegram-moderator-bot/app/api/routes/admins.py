"""
Управление администраторами панели: список, добавление, изменение роли,
удаление. Бизнес-правила (в т.ч. неприкосновенность root-админов)
находятся в AdminService — роуты только валидируют вход и вызывают сервис.
"""

from __future__ import annotations

from aiohttp import web

from app.api.responses import error, ok
from app.core.exceptions import AppError, ValidationAppError
from app.db.models.admin import AdminRole
from app.services.admin_service import AdminService

routes = web.RouteTableDef()

_VALID_ROLES = {r.value for r in AdminRole if r != AdminRole.OWNER}


@routes.get("/api/admins")
async def list_admins(request: web.Request) -> web.Response:
    admins = await AdminService(request["session"]).list_admins()
    return ok(
        [
            {
                "telegram_id": a.telegram_id,
                "username": a.username,
                "full_name": a.full_name,
                "role": a.role.value,
                "is_root": a.is_root,
                "is_active": a.is_active,
                "added_by": a.added_by,
                "last_login_at": a.last_login_at.isoformat() if a.last_login_at else None,
                "created_at": a.created_at.isoformat(),
            }
            for a in admins
        ]
    )


@routes.post("/api/admins")
async def add_admin(request: web.Request) -> web.Response:
    body = await request.json()

    try:
        target_telegram_id = int(body.get("telegram_id"))
    except (TypeError, ValueError):
        raise ValidationAppError("telegram_id должен быть числом")

    role_raw = str(body.get("role") or "").strip()
    if role_raw not in _VALID_ROLES:
        raise ValidationAppError(f"role должна быть одной из: {', '.join(sorted(_VALID_ROLES))}")

    actor = request["current_admin"]
    service = AdminService(request["session"])

    try:
        admin = await service.add_admin(
            actor=actor,
            target_telegram_id=target_telegram_id,
            role=AdminRole(role_raw),
            username=body.get("username"),
            full_name=body.get("full_name"),
        )
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    return ok(
        {
            "telegram_id": admin.telegram_id,
            "role": admin.role.value,
            "is_active": admin.is_active,
        },
        status=201,
    )


@routes.patch("/api/admins/{telegram_id}")
async def change_admin_role(request: web.Request) -> web.Response:
    try:
        target_telegram_id = int(request.match_info["telegram_id"])
    except ValueError:
        raise ValidationAppError("telegram_id должен быть числом")

    body = await request.json()
    role_raw = str(body.get("role") or "").strip()
    if role_raw not in _VALID_ROLES:
        raise ValidationAppError(f"role должна быть одной из: {', '.join(sorted(_VALID_ROLES))}")

    actor = request["current_admin"]
    service = AdminService(request["session"])

    try:
        admin = await service.change_role(
            actor=actor, target_telegram_id=target_telegram_id, new_role=AdminRole(role_raw)
        )
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    return ok({"telegram_id": admin.telegram_id, "role": admin.role.value})


@routes.delete("/api/admins/{telegram_id}")
async def remove_admin(request: web.Request) -> web.Response:
    try:
        target_telegram_id = int(request.match_info["telegram_id"])
    except ValueError:
        raise ValidationAppError("telegram_id должен быть числом")

    actor = request["current_admin"]
    service = AdminService(request["session"])

    try:
        await service.remove_admin(actor=actor, target_telegram_id=target_telegram_id)
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    return ok({"message": "Администратор удалён"})
