"""
GET /api/users — просмотр/поиск пользователей с пагинацией.
GET /api/users/{telegram_id}/history — история модерации конкретного пользователя.
"""

from __future__ import annotations

from aiohttp import web

from app.api.responses import ok
from app.core.exceptions import ValidationAppError
from app.repositories.moderation_repository import ModerationRepository
from app.repositories.user_repository import UserRepository

routes = web.RouteTableDef()

_MAX_LIMIT = 200


def _parse_pagination(request: web.Request) -> tuple[int, int]:
    try:
        limit = min(int(request.query.get("limit", 50)), _MAX_LIMIT)
        offset = max(int(request.query.get("offset", 0)), 0)
    except ValueError as exc:
        raise ValidationAppError("limit и offset должны быть числами") from exc
    return limit, offset


@routes.get("/api/users")
async def list_users(request: web.Request) -> web.Response:
    limit, offset = _parse_pagination(request)
    query = request.query.get("search") or None

    repo = UserRepository(request["session"])
    users = await repo.search(query=query, limit=limit, offset=offset)
    total = await repo.count()

    return ok(
        {
            "items": [
                {
                    "telegram_id": u.telegram_id,
                    "username": u.username,
                    "first_name": u.first_name,
                    "last_name": u.last_name,
                    "first_seen_at": u.first_seen_at.isoformat(),
                    "last_seen_at": u.last_seen_at.isoformat(),
                    "is_globally_banned": u.is_globally_banned,
                }
                for u in users
            ],
            "total": total,
            "limit": limit,
            "offset": offset,
        }
    )


@routes.get("/api/users/{telegram_id}/history")
async def user_history(request: web.Request) -> web.Response:
    try:
        telegram_id = int(request.match_info["telegram_id"])
    except ValueError:
        raise ValidationAppError("telegram_id должен быть числом")

    group_id_raw = request.query.get("group_id")
    group_id = int(group_id_raw) if group_id_raw and group_id_raw.isdigit() else None

    actions = await ModerationRepository(request["session"]).list_for_user(telegram_id, group_id)

    return ok(
        [
            {
                "id": a.id,
                "group_id": a.group_id,
                "action_type": a.action_type.value,
                "admin_id": a.admin_id,
                "reason": a.reason,
                "created_at": a.created_at.isoformat(),
            }
            for a in actions
        ]
    )
