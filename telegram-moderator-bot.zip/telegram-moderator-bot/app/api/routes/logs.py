"""
GET /api/logs             — общий аудит-журнал (входы, добавление админов,
                             группы, ошибки и т.д.)
GET /api/logs/moderation  — журнал действий модерации (мут/бан/кик/варн/...)

Записывается абсолютно всё согласно ТЗ — см. AuditLogRepository.add(),
вызываемый из всех сервисов на каждое значимое действие.
"""

from __future__ import annotations

from aiohttp import web

from app.api.responses import ok
from app.core.exceptions import ValidationAppError
from app.db.models.log import AuditEventType
from app.db.models.moderation import ModerationActionType
from app.repositories.audit_log_repository import AuditLogRepository
from app.repositories.moderation_repository import ModerationRepository

routes = web.RouteTableDef()

_MAX_LIMIT = 200


def _parse_pagination(request: web.Request) -> tuple[int, int]:
    try:
        limit = min(int(request.query.get("limit", 50)), _MAX_LIMIT)
        offset = max(int(request.query.get("offset", 0)), 0)
    except ValueError as exc:
        raise ValidationAppError("limit и offset должны быть числами") from exc
    return limit, offset


@routes.get("/api/logs")
async def list_audit_logs(request: web.Request) -> web.Response:
    limit, offset = _parse_pagination(request)

    event_type_raw = request.query.get("event_type")
    event_type = None
    if event_type_raw:
        try:
            event_type = AuditEventType(event_type_raw)
        except ValueError as exc:
            raise ValidationAppError(f"Некорректный event_type: {event_type_raw}") from exc

    actor_id_raw = request.query.get("actor_id")
    actor_id = int(actor_id_raw) if actor_id_raw and actor_id_raw.isdigit() else None

    entries = await AuditLogRepository(request["session"]).list_recent(
        limit=limit, offset=offset, event_type=event_type, actor_id=actor_id
    )

    return ok(
        [
            {
                "id": e.id,
                "event_type": e.event_type.value,
                "actor_id": e.actor_id,
                "description": e.description,
                "details": e.details,
                "ip_address": e.ip_address,
                "created_at": e.created_at.isoformat(),
            }
            for e in entries
        ]
    )


@routes.get("/api/logs/moderation")
async def list_moderation_logs(request: web.Request) -> web.Response:
    limit, offset = _parse_pagination(request)

    group_id_raw = request.query.get("group_id")
    group_id = int(group_id_raw) if group_id_raw and group_id_raw.isdigit() else None

    action_type_raw = request.query.get("action_type")
    action_type = None
    if action_type_raw:
        try:
            action_type = ModerationActionType(action_type_raw)
        except ValueError as exc:
            raise ValidationAppError(f"Некорректный action_type: {action_type_raw}") from exc

    actions = await ModerationRepository(request["session"]).list_recent(
        limit=limit, offset=offset, group_id=group_id, action_type=action_type
    )

    return ok(
        [
            {
                "id": a.id,
                "group_id": a.group_id,
                "target_user_id": a.target_user_id,
                "admin_id": a.admin_id,
                "action_type": a.action_type.value,
                "reason": a.reason,
                "duration_seconds": a.duration_seconds,
                "created_at": a.created_at.isoformat(),
            }
            for a in actions
        ]
    )
