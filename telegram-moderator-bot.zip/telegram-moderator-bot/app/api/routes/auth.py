"""
Эндпоинты авторизации в WebApp панель:
  POST /api/auth/request-code  — шаг 1-3 из ТЗ: проверка ID, отправка кода
  POST /api/auth/verify-code   — шаг 4-5: проверка кода, выдача сессии
  POST /api/auth/logout        — завершение сессии
  GET  /api/auth/me            — данные текущего администратора (для восстановления сессии на фронте)

initData Telegram WebApp проверяется на обоих auth-эндпоинтах — это
подтверждает, что запрос пришёл из настоящего Telegram-клиента, а не
с произвольного сайта, дополнительно к проверке кода подтверждения.
"""

from __future__ import annotations

from aiohttp import web

from app.api.middlewares.auth_middleware import SESSION_COOKIE_NAME
from app.api.responses import error, ok
from app.bot.code_sender import TelegramCodeSender
from app.config import get_settings
from app.core.exceptions import AppError, InvalidInitDataError, ValidationAppError
from app.core.security import (
    decode_session_token,
    generate_csrf_token,
    validate_telegram_init_data,
)
from app.repositories.admin_repository import AdminRepository
from app.services.auth_service import AuthService

routes = web.RouteTableDef()
_settings = get_settings()


def _extract_telegram_id(body: dict) -> int:
    raw = body.get("telegram_id")
    if raw is None:
        raise ValidationAppError("Поле telegram_id обязательно")
    try:
        return int(raw)
    except (TypeError, ValueError) as exc:
        raise ValidationAppError("telegram_id должен быть числом") from exc


def _validate_init_data(body: dict) -> None:
    init_data = body.get("init_data")
    if not init_data:
        raise InvalidInitDataError("Отсутствует init_data — откройте панель через Telegram")
    validate_telegram_init_data(init_data)


@routes.post("/api/auth/request-code")
async def request_code(request: web.Request) -> web.Response:
    body = await request.json()
    _validate_init_data(body)
    telegram_id = _extract_telegram_id(body)

    bot = request.app["bot"]
    service = AuthService(request["session"], TelegramCodeSender(bot))

    try:
        await service.request_login_code(
            telegram_id=telegram_id,
            ip_address=request.remote,
            user_agent=request.headers.get("User-Agent"),
        )
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    return ok({"message": "Код подтверждения отправлен в Telegram", "ttl_seconds": _settings.auth_code_ttl_seconds})


@routes.post("/api/auth/verify-code")
async def verify_code(request: web.Request) -> web.Response:
    body = await request.json()
    _validate_init_data(body)
    telegram_id = _extract_telegram_id(body)

    code = str(body.get("code") or "").strip()
    if not code:
        raise ValidationAppError("Поле code обязательно")

    bot = request.app["bot"]
    service = AuthService(request["session"], TelegramCodeSender(bot))

    try:
        token = await service.verify_login_code(
            telegram_id=telegram_id,
            provided_code=code,
            ip_address=request.remote,
            user_agent=request.headers.get("User-Agent"),
        )
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    payload = decode_session_token(token)
    csrf_token = generate_csrf_token(payload.session_id)

    admin = await AdminRepository(request["session"]).get_by_id(telegram_id)

    response = ok(
        {
            "admin": {
                "telegram_id": admin.telegram_id,
                "role": admin.role.value,
                "is_root": admin.is_root,
                "username": admin.username,
            },
            "csrf_token": csrf_token,
        }
    )
    response.set_cookie(
        SESSION_COOKIE_NAME,
        token,
        httponly=True,
        secure=_settings.is_production,
        samesite="Strict",
        max_age=_settings.jwt_access_ttl_minutes * 60,
    )
    # CSRF-токен намеренно НЕ httpOnly: фронтенд должен прочитать его из cookie
    # после перезагрузки страницы, чтобы не требовать повторный вход только
    # из-за F5 (double-submit cookie pattern). Токен без session_token всё
    # равно бесполезен — подпись проверяется вместе с session_id из JWT.
    response.set_cookie(
        "csrf_token",
        csrf_token,
        httponly=False,
        secure=_settings.is_production,
        samesite="Strict",
        max_age=_settings.jwt_access_ttl_minutes * 60,
    )
    return response


@routes.post("/api/auth/logout")
async def logout(request: web.Request) -> web.Response:
    response = ok({"message": "Вы вышли из системы"})
    response.del_cookie(SESSION_COOKIE_NAME)
    response.del_cookie("csrf_token")
    return response


@routes.get("/api/auth/me")
async def me(request: web.Request) -> web.Response:
    admin = request.get("current_admin")
    if admin is None:
        return error("unauthorized", "Требуется авторизация", status=401)

    return ok(
        {
            "telegram_id": admin.telegram_id,
            "role": admin.role.value,
            "is_root": admin.is_root,
            "username": admin.username,
            "full_name": admin.full_name,
        }
    )
