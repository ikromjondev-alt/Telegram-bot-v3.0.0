"""
POST /api/broadcast/upload      — загрузить медиа-файл, получить настоящий file_id
POST /api/broadcast            — создать рассылку (предпросмотр создаётся на фронте
                                  из тех же полей, отдельного эндпоинта не требует)
POST /api/broadcast/{id}/send  — запустить отправку (фоновая задача)
GET  /api/broadcast            — список рассылок со статистикой
GET  /api/broadcast/{id}       — статус и статистика конкретной рассылки
"""

from __future__ import annotations

import asyncio

from aiogram.types import BufferedInputFile
from aiohttp import web

from app.api.responses import error, ok
from app.core.exceptions import AppError, ForbiddenError, ValidationAppError
from app.db.models.broadcast import BroadcastContentType, BroadcastStatus
from app.services.broadcast_service import BroadcastService, run_broadcast

routes = web.RouteTableDef()

_VALID_CONTENT_TYPES = {c.value for c in BroadcastContentType}
_UPLOADABLE_TYPES = _VALID_CONTENT_TYPES - {BroadcastContentType.TEXT.value}
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # лимит загрузки файлов Telegram Bot API


@routes.post("/api/broadcast/upload")
async def upload_media(request: web.Request) -> web.Response:
    """
    Загружает файл через бота в личный чат администратора (получает превью
    и настоящий file_id, пригодный для последующей массовой рассылки —
    Telegram позволяет переиспользовать file_id без повторной загрузки).
    """
    admin = request["current_admin"]
    if not admin.can_moderate():
        raise ForbiddenError("Недостаточно прав для загрузки медиа")

    content_type_raw = request.query.get("content_type", "")
    if content_type_raw not in _UPLOADABLE_TYPES:
        raise ValidationAppError(f"content_type должен быть одним из: {', '.join(sorted(_UPLOADABLE_TYPES))}")

    reader = await request.multipart()
    field = await reader.next()
    if field is None or field.name != "file":
        raise ValidationAppError("Ожидается multipart-поле 'file'")

    data = await field.read(decode=False)
    if not data:
        raise ValidationAppError("Пустой файл")
    if len(data) > _MAX_UPLOAD_BYTES:
        raise ValidationAppError("Файл превышает лимит Telegram Bot API (50 МБ)")

    filename = field.filename or "upload"
    input_file = BufferedInputFile(data, filename=filename)
    bot = request.app["bot"]
    content_type = BroadcastContentType(content_type_raw)

    try:
        if content_type == BroadcastContentType.PHOTO:
            message = await bot.send_photo(admin.telegram_id, input_file, caption="Предпросмотр загрузки")
            file_id = message.photo[-1].file_id
        elif content_type == BroadcastContentType.VIDEO:
            message = await bot.send_video(admin.telegram_id, input_file, caption="Предпросмотр загрузки")
            file_id = message.video.file_id
        elif content_type == BroadcastContentType.DOCUMENT:
            message = await bot.send_document(admin.telegram_id, input_file, caption="Предпросмотр загрузки")
            file_id = message.document.file_id
        else:  # ANIMATION
            message = await bot.send_animation(admin.telegram_id, input_file, caption="Предпросмотр загрузки")
            file_id = message.animation.file_id
    except Exception as exc:  # noqa: BLE001
        raise ValidationAppError(
            "Не удалось загрузить файл в Telegram: убедитесь, что вы писали боту /start"
        ) from exc

    return ok({"file_id": file_id})


def _serialize(b) -> dict:
    return {
        "id": b.id,
        "created_by": b.created_by,
        "content_type": b.content_type.value,
        "text": b.text,
        "file_id": b.file_id,
        "buttons": b.buttons,
        "status": b.status.value,
        "target_count": b.target_count,
        "sent_count": b.sent_count,
        "failed_count": b.failed_count,
        "started_at": b.started_at.isoformat() if b.started_at else None,
        "completed_at": b.completed_at.isoformat() if b.completed_at else None,
        "created_at": b.created_at.isoformat(),
    }


@routes.post("/api/broadcast")
async def create_broadcast(request: web.Request) -> web.Response:
    admin = request["current_admin"]
    if not admin.can_moderate():
        raise ForbiddenError("Недостаточно прав для создания рассылки")

    body = await request.json()
    content_type_raw = str(body.get("content_type") or "").strip()
    if content_type_raw not in _VALID_CONTENT_TYPES:
        raise ValidationAppError(f"content_type должен быть одним из: {', '.join(sorted(_VALID_CONTENT_TYPES))}")

    buttons = body.get("buttons")
    if buttons is not None and not isinstance(buttons, list):
        raise ValidationAppError("buttons должен быть списком строк кнопок")

    service = BroadcastService(request["session"])
    try:
        broadcast = await service.create_broadcast(
            created_by=admin.telegram_id,
            content_type=BroadcastContentType(content_type_raw),
            text=body.get("text"),
            file_id=body.get("file_id"),
            buttons=buttons,
        )
    except AppError as exc:
        return error(exc.code, exc.message, status=exc.http_status)

    return ok(_serialize(broadcast), status=201)


@routes.post("/api/broadcast/{broadcast_id}/send")
async def send_broadcast(request: web.Request) -> web.Response:
    admin = request["current_admin"]
    if not admin.can_moderate():
        raise ForbiddenError("Недостаточно прав для запуска рассылки")

    try:
        broadcast_id = int(request.match_info["broadcast_id"])
    except ValueError:
        raise ValidationAppError("broadcast_id должен быть числом")

    service = BroadcastService(request["session"])
    broadcast = await service.get_broadcast(broadcast_id)
    if broadcast is None:
        return error("not_found", "Рассылка не найдена", status=404)

    if broadcast.status != BroadcastStatus.QUEUED:
        raise ValidationAppError("Рассылка уже отправлена или отправляется")

    bot = request.app["bot"]
    asyncio.create_task(run_broadcast(broadcast_id, bot))

    return ok({"message": "Рассылка запущена", "broadcast_id": broadcast_id})


@routes.get("/api/broadcast")
async def list_broadcasts(request: web.Request) -> web.Response:
    limit = min(int(request.query.get("limit", 50)), 200)
    offset = max(int(request.query.get("offset", 0)), 0)

    service = BroadcastService(request["session"])
    items = await service.list_broadcasts(limit=limit, offset=offset)
    return ok([_serialize(b) for b in items])


@routes.get("/api/broadcast/{broadcast_id}")
async def get_broadcast(request: web.Request) -> web.Response:
    try:
        broadcast_id = int(request.match_info["broadcast_id"])
    except ValueError:
        raise ValidationAppError("broadcast_id должен быть числом")

    service = BroadcastService(request["session"])
    broadcast = await service.get_broadcast(broadcast_id)
    if broadcast is None:
        return error("not_found", "Рассылка не найдена", status=404)

    return ok(_serialize(broadcast))
