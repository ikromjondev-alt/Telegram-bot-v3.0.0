"""
Точка входа процесса API. Запуск: python -m app.api.main
Бот (polling) запускается отдельным процессом: python -m app.main
"""

from __future__ import annotations

import logging

from aiohttp import web

from app.api.app import create_app
from app.config import get_settings

_settings = get_settings()

logging.basicConfig(
    level=_settings.log_level,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)

if __name__ == "__main__":
    web.run_app(create_app(), host=_settings.api_host, port=_settings.api_port)
