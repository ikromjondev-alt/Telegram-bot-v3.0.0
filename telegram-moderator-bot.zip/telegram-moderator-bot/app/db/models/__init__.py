"""
Импорт всех моделей в одном месте — обязателен для того, чтобы
Alembic autogenerate видел полную метадату при сравнении схемы.
"""

from app.db.models.admin import Admin, AdminRole
from app.db.models.auth import AuthCode
from app.db.models.broadcast import Broadcast, BroadcastContentType, BroadcastStatus
from app.db.models.group import Group, GroupSettings
from app.db.models.log import AuditEventType, AuditLog
from app.db.models.moderation import ModerationAction, ModerationActionType
from app.db.models.user import TelegramUser, UserGroupStat

__all__ = [
    "Admin",
    "AdminRole",
    "AuthCode",
    "Broadcast",
    "BroadcastContentType",
    "BroadcastStatus",
    "Group",
    "GroupSettings",
    "AuditEventType",
    "AuditLog",
    "ModerationAction",
    "ModerationActionType",
    "TelegramUser",
    "UserGroupStat",
]
