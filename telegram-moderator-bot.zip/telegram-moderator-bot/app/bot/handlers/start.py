"""
/start в личном чате с ботом. Нужен, чтобы Telegram разрешил боту писать
администратору (без исходящего сообщения от пользователя боту бот не может
первым отправить код подтверждения — ограничение Telegram Bot API).
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.admin_repository import AdminRepository

router = Router(name="start")
router.message.filter(F.chat.type == "private")


@router.message(CommandStart())
async def cmd_start(message: Message, session: AsyncSession) -> None:
    if message.from_user is None:
        return

    admin = await AdminRepository(session).get_by_id(message.from_user.id)

    if admin is not None and admin.is_active:
        await AdminRepository(session).update_profile(
            admin, username=message.from_user.username, full_name=message.from_user.full_name
        )
        text = (
            "Здравствуйте! Вы зарегистрированы как администратор панели модерации.\n\n"
            "Чтобы войти в панель, откройте WebApp и введите свой Telegram ID — "
            "бот пришлёт сюда код подтверждения."
        )
    else:
        text = "Здравствуйте! Этот бот управляет модерацией групп через WebApp панель администратора."

    await message.answer(text)
