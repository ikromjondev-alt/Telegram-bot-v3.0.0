"""
Обрабатывает изменение статуса бота в чате: когда бота добавляют в группу —
группа автоматически подключается к модерации; когда удаляют/кикают —
отключается.
"""

from __future__ import annotations

from aiogram import Router
from aiogram.enums import ChatMemberStatus
from aiogram.types import ChatMemberUpdated
from sqlalchemy.ext.asyncio import AsyncSession

from app.services.group_service import GroupService

router = Router(name="group_management")

_ACTIVE_STATUSES = {ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR}
_INACTIVE_STATUSES = {ChatMemberStatus.LEFT, ChatMemberStatus.KICKED, ChatMemberStatus.RESTRICTED}


@router.my_chat_member()
async def on_bot_membership_changed(event: ChatMemberUpdated, session: AsyncSession) -> None:
    new_status = event.new_chat_member.status
    chat = event.chat

    if chat.type not in ("group", "supergroup"):
        return

    service = GroupService(session)

    if new_status in _ACTIVE_STATUSES:
        member_count = await event.bot.get_chat_member_count(chat.id)
        await service.connect_group(
            chat_id=chat.id,
            title=chat.title or str(chat.id),
            added_by=event.from_user.id,
            username=chat.username,
            members_count=member_count,
        )
    elif new_status in _INACTIVE_STATUSES:
        await service.disconnect_group(chat_id=chat.id, actor_id=event.from_user.id)
