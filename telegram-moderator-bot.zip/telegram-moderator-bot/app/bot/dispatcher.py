"""
Точка сборки бота: создаёт Bot/Dispatcher, регистрирует middlewares
и роутеры в правильном порядке.

Порядок регистрации роутеров важен:
  1. start              — приватные команды
  2. group_management   — my_chat_member (добавление/удаление бота из группы)
  3. moderation_commands — ручные команды модерации (имеют приоритет,
                            фильтруются по IsPanelAdmin)
  4. group_messages     — общий поток сообщений группы (антиспам/антифлуд),
                            регистрируется последним, чтобы не перехватывать
                            команды модерации раньше времени
"""

from __future__ import annotations

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from app.bot.handlers import group_management, group_messages, moderation_commands, start
from app.bot.middlewares.db_session import DatabaseSessionMiddleware
from app.config import get_settings

_settings = get_settings()


def create_bot() -> Bot:
    return Bot(
        token=_settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


def create_dispatcher() -> Dispatcher:
    dispatcher = Dispatcher()

    dispatcher.update.middleware(DatabaseSessionMiddleware())

    dispatcher.include_router(start.router)
    dispatcher.include_router(group_management.router)
    dispatcher.include_router(moderation_commands.router)
    dispatcher.include_router(group_messages.router)

    return dispatcher
