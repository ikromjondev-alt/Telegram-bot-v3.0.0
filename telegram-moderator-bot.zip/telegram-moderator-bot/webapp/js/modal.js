// =============================================================================
// Modal utility — плавное появление/закрытие, закрытие по Esc/фону
// =============================================================================

export function openModal(innerHtml, { onMount, maxWidth } = {}) {
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";

  const modal = document.createElement("div");
  modal.className = "glass glass--heavy modal";
  if (maxWidth) modal.style.maxWidth = maxWidth;
  modal.innerHTML = `
    <button class="modal__close" data-modal-close aria-label="Закрыть">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
    </button>
    ${innerHtml}
  `;

  backdrop.appendChild(modal);
  document.body.appendChild(backdrop);
  document.body.style.overflow = "hidden";

  function close() {
    backdrop.classList.add("is-closing");
    backdrop.addEventListener(
      "animationend",
      () => {
        backdrop.remove();
        document.body.style.overflow = "";
      },
      { once: true }
    );
  }

  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) close();
  });
  modal.querySelector("[data-modal-close]").addEventListener("click", close);

  const onKeydown = (event) => {
    if (event.key === "Escape") {
      close();
      document.removeEventListener("keydown", onKeydown);
    }
  };
  document.addEventListener("keydown", onKeydown);

  onMount?.(modal, close);

  return { modal, close };
}

export function confirmModal({ title, message, confirmLabel, danger = true, onConfirm }) {
  openModal(
    `
      <h2 style="font-size: var(--fs-lg); margin-bottom: 12px;">${title}</h2>
      <p style="color: var(--text-secondary); font-size: var(--fs-sm); margin-bottom: 20px;">${message}</p>
      <div class="form-actions">
        <button class="btn btn--glass" data-cancel>Отмена</button>
        <button class="btn ${danger ? "btn--danger" : "btn--primary"}" data-confirm>${confirmLabel}</button>
      </div>
    `,
    {
      onMount(modal, close) {
        modal.querySelector("[data-cancel]").addEventListener("click", close);
        modal.querySelector("[data-confirm]").addEventListener("click", async () => {
          await onConfirm();
          close();
        });
      },
    }
  );
}
