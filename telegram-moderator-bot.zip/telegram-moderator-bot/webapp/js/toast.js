// =============================================================================
// Toast notifications
// =============================================================================

let stack = null;

function ensureStack() {
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  return stack;
}

const ICONS = {
  success:
    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  error:
    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};

export function showToast(message, { type = "success", duration = 3200 } = {}) {
  const root = ensureStack();
  const el = document.createElement("div");
  el.className = `toast glass toast--${type}`;
  el.innerHTML = `<span class="toast__icon">${ICONS[type] ?? ICONS.success}</span><span>${message}</span>`;
  root.appendChild(el);

  const remove = () => {
    el.classList.add("is-leaving");
    el.addEventListener("animationend", () => el.remove(), { once: true });
  };

  setTimeout(remove, duration);
  el.addEventListener("click", remove);
}
