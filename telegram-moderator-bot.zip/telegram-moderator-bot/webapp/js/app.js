// =============================================================================
// App bootstrap
// =============================================================================

import { api, ApiError, setCsrfToken } from "./api.js";
import { initTelegramWebApp } from "./telegram-webapp.js";
import { initRipples } from "./ripple.js";
import { mountAuthScreen } from "./auth.js";
import { mountAppShell } from "./shell.js";
import { renderDashboard } from "./views/dashboard.js";
import { renderUsers } from "./views/users.js";
import { renderGroups } from "./views/groups.js";
import { renderLogs } from "./views/logs.js";
import { renderBroadcast } from "./views/broadcast.js";
import { renderAdmins } from "./views/admins.js";
import { renderSettings } from "./views/settings.js";
import { t } from "./i18n.js";

const root = document.getElementById("app");

function makeViewRenderers(admin) {
  return {
    dashboard: renderDashboard,
    users: renderUsers,
    groups: renderGroups,
    logs: renderLogs,
    broadcast: renderBroadcast,
    admins: (container) => renderAdmins(container, admin),
    settings: renderSettings,
  };
}

function bootShell(admin) {
  const viewRenderers = makeViewRenderers(admin);

  const { setActive } = mountAppShell(root, {
    admin,
    onNavigate(viewId, contentEl) {
      const renderer = viewRenderers[viewId];
      renderer?.(contentEl);
    },
    onLogout() {
      bootAuth();
    },
  });

  setActive("dashboard");
  viewRenderers.dashboard(document.querySelector("[data-view-content]"));
}

function bootAuth() {
  setCsrfToken(null);
  mountAuthScreen(root, (admin) => bootShell(admin));
}

function readCsrfCookie() {
  const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}

async function bootstrap() {
  initTelegramWebApp();
  initRipples();

  try {
    const admin = await api.get("/auth/me");
    setCsrfToken(readCsrfCookie());
    bootShell(admin);
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) {
      bootAuth();
    } else {
      root.innerHTML = `
        <div class="auth-screen">
          <div class="glass glass--heavy auth-card">
            <h1 class="auth-title">${t("common.error")}</h1>
            <p class="auth-subtitle">${err.message ?? ""}</p>
            <button class="btn btn--primary" onclick="location.reload()">${t("common.retry")}</button>
          </div>
        </div>
      `;
    }
  }
}

bootstrap();
