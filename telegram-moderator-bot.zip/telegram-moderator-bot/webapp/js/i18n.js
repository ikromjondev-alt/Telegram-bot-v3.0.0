// =============================================================================
// i18n — переключение языка панели без перезагрузки страницы (ru / uz)
// =============================================================================

const STORAGE_KEY = "panel_language";

const dictionaries = {
  ru: {
    "auth.title": "Вход в панель",
    "auth.subtitle": "Введите свой Telegram ID администратора, чтобы получить код подтверждения",
    "auth.id_label": "Telegram ID",
    "auth.id_placeholder": "Например, 123456789",
    "auth.send_code": "Отправить код",
    "auth.code_title": "Введите код",
    "auth.code_subtitle": "Код отправлен в Telegram и действует 120 секунд",
    "auth.code_hint": "Проверьте личные сообщения от бота",
    "auth.verify": "Войти",
    "auth.back": "Назад",
    "auth.resend": "Отправить код повторно",
    "auth.expired": "Код истёк, запросите новый",
    "auth.error.forbidden": "Доступ запрещён: этот Telegram ID не найден среди администраторов",
    "auth.error.invalid_code": "Неверный код подтверждения",
    "auth.error.generic": "Не удалось выполнить вход. Попробуйте снова",
    "auth.footer": "Максимальная безопасность · initData проверяется на сервере",

    "nav.dashboard": "Обзор",
    "nav.users": "Пользователи",
    "nav.groups": "Группы",
    "nav.logs": "Логи",
    "nav.broadcast": "Рассылка",
    "nav.admins": "Администраторы",
    "nav.settings": "Настройки",

    "dashboard.groups": "Группы",
    "dashboard.users": "Пользователи",
    "dashboard.deleted": "Удалено сообщений",
    "dashboard.warns": "Предупреждения",
    "dashboard.mutes": "Муты",
    "dashboard.bans": "Баны",
    "dashboard.kicks": "Кики",
    "dashboard.bot_status": "Статус бота",
    "dashboard.online": "Онлайн",
    "dashboard.offline": "Офлайн",
    "dashboard.ram": "Память",
    "dashboard.cpu": "Процессор",
    "dashboard.ping": "Ping",
    "dashboard.uptime": "Uptime",
    "dashboard.last_activity": "Последняя активность",
    "dashboard.no_activity": "Действий пока не было",

    "common.loading": "Загрузка…",
    "common.retry": "Повторить",
    "common.save": "Сохранить",
    "common.cancel": "Отмена",
    "common.delete": "Удалить",
    "common.add": "Добавить",
    "common.search": "Поиск",
    "common.logout": "Выйти",
    "common.saved": "Изменения сохранены",
    "common.error": "Что-то пошло не так",
    "common.load_more": "Загрузить ещё",
    "common.empty": "Здесь пока пусто",
    "common.confirm": "Подтвердить",
    "common.close": "Закрыть",

    "users.title": "Пользователи",
    "users.search_placeholder": "Поиск по username или имени",
    "users.total": "Всего пользователей",
    "users.banned": "Забанен",
    "users.history": "История модерации",
    "users.no_history": "Действий модерации не найдено",
    "users.first_seen": "Первое появление",
    "users.last_seen": "Последняя активность",

    "groups.title": "Группы",
    "groups.members": "участников",
    "groups.disconnect": "Отключить",
    "groups.disconnect_confirm_title": "Отключить группу?",
    "groups.disconnect_confirm_message": "Бот останется в группе, но перестанет модерировать её. Настройки будут удалены.",
    "groups.configure": "Настроить",
    "groups.settings_title": "Настройки модерации",
    "groups.mute_duration": "Время мута (мин)",
    "groups.warn_limit": "Лимит предупреждений",
    "groups.flood_limit": "Сообщений в антифлуд-окне",
    "groups.flood_window": "Окно антифлуда (сек)",
    "groups.antispam": "Антиспам",
    "groups.antiflood": "Антифлуд",
    "groups.autodelete": "Автоудаление служебных",
    "groups.logs_enabled": "Логировать действия",
    "groups.notifications_enabled": "Уведомления в группе",
    "groups.language": "Язык бота в группе",
    "groups.empty": "Нет подключённых групп. Добавьте бота в группу в Telegram.",

    "logs.title": "Логи",
    "logs.tab_audit": "Аудит",
    "logs.tab_moderation": "Модерация",
    "logs.filter_all": "Все события",
    "logs.actor": "Инициатор",
    "logs.system": "Система",

    "broadcast.title": "Рассылка",
    "broadcast.new": "Новая рассылка",
    "broadcast.type": "Тип содержимого",
    "broadcast.text": "Текст",
    "broadcast.photo": "Фото",
    "broadcast.video": "Видео",
    "broadcast.document": "Документ",
    "broadcast.animation": "GIF",
    "broadcast.text_label": "Текст сообщения",
    "broadcast.upload_hint": "Нажмите или перетащите файл",
    "broadcast.buttons": "Кнопки (текст + ссылка)",
    "broadcast.add_button": "Добавить кнопку",
    "broadcast.preview": "Предпросмотр",
    "broadcast.create": "Создать рассылку",
    "broadcast.send": "Отправить",
    "broadcast.status.draft": "Черновик",
    "broadcast.status.queued": "В очереди",
    "broadcast.status.sending": "Отправляется",
    "broadcast.status.completed": "Завершена",
    "broadcast.status.failed": "Ошибка",
    "broadcast.sent": "Отправлено",
    "broadcast.failed": "Ошибок",
    "broadcast.target": "Получателей",
    "broadcast.empty": "Рассылок пока не было",

    "admins.title": "Администраторы",
    "admins.add": "Добавить администратора",
    "admins.id_label": "Telegram ID",
    "admins.role_label": "Уровень доступа",
    "admins.role.owner": "Владелец",
    "admins.role.admin": "Администратор",
    "admins.role.moderator": "Модератор",
    "admins.role.viewer": "Наблюдатель",
    "admins.root_badge": "Главный",
    "admins.remove_confirm_title": "Удалить администратора?",
    "admins.remove_confirm_message": "Он потеряет доступ к панели немедленно.",
    "admins.root_protected": "Главного администратора нельзя удалить или изменить",
    "admins.last_login": "Последний вход",
    "admins.never": "Ещё не входил",

    "settings.title": "Настройки модерации по группам",
    "settings.subtitle": "Выберите группу, чтобы настроить параметры модерации",
  },
  uz: {
    "auth.title": "Panelga kirish",
    "auth.subtitle": "Tasdiqlash kodini olish uchun administrator Telegram ID raqamingizni kiriting",
    "auth.id_label": "Telegram ID",
    "auth.id_placeholder": "Masalan, 123456789",
    "auth.send_code": "Kodni yuborish",
    "auth.code_title": "Kodni kiriting",
    "auth.code_subtitle": "Kod Telegramga yuborildi va 120 soniya amal qiladi",
    "auth.code_hint": "Botdan kelgan shaxsiy xabarlarni tekshiring",
    "auth.verify": "Kirish",
    "auth.back": "Orqaga",
    "auth.resend": "Kodni qayta yuborish",
    "auth.expired": "Kod muddati tugadi, yangisini so'rang",
    "auth.error.forbidden": "Kirish taqiqlangan: bu Telegram ID administratorlar orasida topilmadi",
    "auth.error.invalid_code": "Noto'g'ri tasdiqlash kodi",
    "auth.error.generic": "Kirishning imkoni bo'lmadi. Qayta urinib ko'ring",
    "auth.footer": "Maksimal xavfsizlik · initData serverda tekshiriladi",

    "nav.dashboard": "Umumiy",
    "nav.users": "Foydalanuvchilar",
    "nav.groups": "Guruhlar",
    "nav.logs": "Loglar",
    "nav.broadcast": "Xabar yuborish",
    "nav.admins": "Administratorlar",
    "nav.settings": "Sozlamalar",

    "dashboard.groups": "Guruhlar",
    "dashboard.users": "Foydalanuvchilar",
    "dashboard.deleted": "O'chirilgan xabarlar",
    "dashboard.warns": "Ogohlantirishlar",
    "dashboard.mutes": "Mutlar",
    "dashboard.bans": "Banlar",
    "dashboard.kicks": "Chiqarishlar",
    "dashboard.bot_status": "Bot holati",
    "dashboard.online": "Onlayn",
    "dashboard.offline": "Oflayn",
    "dashboard.ram": "Xotira",
    "dashboard.cpu": "Protsessor",
    "dashboard.ping": "Ping",
    "dashboard.uptime": "Ishlash vaqti",
    "dashboard.last_activity": "Oxirgi faollik",
    "dashboard.no_activity": "Hali harakatlar bo'lmagan",

    "common.loading": "Yuklanmoqda…",
    "common.retry": "Qayta urinish",
    "common.save": "Saqlash",
    "common.cancel": "Bekor qilish",
    "common.delete": "O'chirish",
    "common.add": "Qo'shish",
    "common.search": "Qidiruv",
    "common.logout": "Chiqish",
    "common.saved": "O'zgarishlar saqlandi",
    "common.error": "Nimadir noto'g'ri ketdi",
    "common.load_more": "Yana yuklash",
    "common.empty": "Bu yerda hali hech narsa yo'q",
    "common.confirm": "Tasdiqlash",
    "common.close": "Yopish",

    "users.title": "Foydalanuvchilar",
    "users.search_placeholder": "Username yoki ism bo'yicha qidirish",
    "users.total": "Jami foydalanuvchilar",
    "users.banned": "Banlangan",
    "users.history": "Moderatsiya tarixi",
    "users.no_history": "Moderatsiya harakatlari topilmadi",
    "users.first_seen": "Birinchi ko'rinish",
    "users.last_seen": "Oxirgi faollik",

    "groups.title": "Guruhlar",
    "groups.members": "a'zolar",
    "groups.disconnect": "Uzish",
    "groups.disconnect_confirm_title": "Guruhni uzasizmi?",
    "groups.disconnect_confirm_message": "Bot guruhda qoladi, lekin moderatsiyani to'xtatadi. Sozlamalar o'chiriladi.",
    "groups.configure": "Sozlash",
    "groups.settings_title": "Moderatsiya sozlamalari",
    "groups.mute_duration": "Mute vaqti (daqiqa)",
    "groups.warn_limit": "Ogohlantirish chegarasi",
    "groups.flood_limit": "Antiflood oynasidagi xabarlar",
    "groups.flood_window": "Antiflood oynasi (soniya)",
    "groups.antispam": "Antispam",
    "groups.antiflood": "Antiflood",
    "groups.autodelete": "Xizmat xabarlarini avto-o'chirish",
    "groups.logs_enabled": "Harakatlarni loglash",
    "groups.notifications_enabled": "Guruhda bildirishnomalar",
    "groups.language": "Guruhda bot tili",
    "groups.empty": "Ulangan guruhlar yo'q. Botni Telegram guruhiga qo'shing.",

    "logs.title": "Loglar",
    "logs.tab_audit": "Audit",
    "logs.tab_moderation": "Moderatsiya",
    "logs.filter_all": "Barcha hodisalar",
    "logs.actor": "Bajaruvchi",
    "logs.system": "Tizim",

    "broadcast.title": "Xabar yuborish",
    "broadcast.new": "Yangi xabar",
    "broadcast.type": "Kontent turi",
    "broadcast.text": "Matn",
    "broadcast.photo": "Rasm",
    "broadcast.video": "Video",
    "broadcast.document": "Hujjat",
    "broadcast.animation": "GIF",
    "broadcast.text_label": "Xabar matni",
    "broadcast.upload_hint": "Bosing yoki faylni tashlang",
    "broadcast.buttons": "Tugmalar (matn + havola)",
    "broadcast.add_button": "Tugma qo'shish",
    "broadcast.preview": "Oldindan ko'rish",
    "broadcast.create": "Xabar yaratish",
    "broadcast.send": "Yuborish",
    "broadcast.status.draft": "Qoralama",
    "broadcast.status.queued": "Navbatda",
    "broadcast.status.sending": "Yuborilmoqda",
    "broadcast.status.completed": "Yakunlandi",
    "broadcast.status.failed": "Xatolik",
    "broadcast.sent": "Yuborildi",
    "broadcast.failed": "Xatoliklar",
    "broadcast.target": "Qabul qiluvchilar",
    "broadcast.empty": "Hali xabarlar bo'lmagan",

    "admins.title": "Administratorlar",
    "admins.add": "Administrator qo'shish",
    "admins.id_label": "Telegram ID",
    "admins.role_label": "Ruxsat darajasi",
    "admins.role.owner": "Egasi",
    "admins.role.admin": "Administrator",
    "admins.role.moderator": "Moderator",
    "admins.role.viewer": "Kuzatuvchi",
    "admins.root_badge": "Asosiy",
    "admins.remove_confirm_title": "Administratorni o'chirasizmi?",
    "admins.remove_confirm_message": "U panelga kirish huquqini darhol yo'qotadi.",
    "admins.root_protected": "Asosiy administratorni o'chirib yoki o'zgartirib bo'lmaydi",
    "admins.last_login": "Oxirgi kirish",
    "admins.never": "Hali kirmagan",

    "settings.title": "Guruhlar bo'yicha moderatsiya sozlamalari",
    "settings.subtitle": "Moderatsiya parametrlarini sozlash uchun guruhni tanlang",
  },
};

let currentLang = localStorage.getItem(STORAGE_KEY) || "ru";
const listeners = new Set();

export function t(key) {
  return dictionaries[currentLang]?.[key] ?? dictionaries.ru[key] ?? key;
}

export function getLanguage() {
  return currentLang;
}

export function setLanguage(lang) {
  if (!dictionaries[lang] || lang === currentLang) return;
  currentLang = lang;
  localStorage.setItem(STORAGE_KEY, lang);
  document.documentElement.lang = lang;
  applyTranslations();
  listeners.forEach((cb) => cb(lang));
}

export function onLanguageChange(callback) {
  listeners.add(callback);
  return () => listeners.delete(callback);
}

/** Применяет переводы ко всем элементам с data-i18n без перезагрузки страницы. */
export function applyTranslations(root = document) {
  root.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  root.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    el.setAttribute("placeholder", t(el.dataset.i18nPlaceholder));
  });
}

document.documentElement.lang = currentLang;
