// =============================================================================
// API client — единая точка HTTP-запросов к backend
// =============================================================================

const API_BASE = window.__APP_CONFIG__?.apiBaseUrl ?? "/api";

let csrfToken = null;

export function setCsrfToken(token) {
  csrfToken = token;
}

export class ApiError extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

async function request(method, path, { body, query } = {}) {
  const url = new URL(API_BASE + path, window.location.origin);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, value);
      }
    }
  }

  const headers = { "Content-Type": "application/json" };
  const isMutating = !["GET", "HEAD", "OPTIONS"].includes(method);
  if (isMutating && csrfToken) {
    headers["X-CSRF-Token"] = csrfToken;
  }

  const response = await fetch(url.toString(), {
    method,
    headers,
    credentials: "include",
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new ApiError("network_error", "Сервер вернул некорректный ответ", response.status);
  }

  if (!response.ok || payload.ok === false) {
    const err = payload.error ?? { code: "unknown_error", message: "Неизвестная ошибка" };
    throw new ApiError(err.code, err.message, response.status);
  }

  return payload.data;
}

export const api = {
  get: (path, query) => request("GET", path, { query }),
  post: (path, body) => request("POST", path, { body }),
  patch: (path, body) => request("PATCH", path, { body }),
  delete: (path) => request("DELETE", path),
};

/**
 * Загрузка файла через multipart/form-data (для рассылок: фото/видео/документ/GIF).
 * Не переиспользует request(), так как Content-Type для FormData браузер
 * должен выставить сам (с корректным multipart boundary).
 */
export async function uploadFile(path, file, query) {
  const url = new URL(API_BASE + path, window.location.origin);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      url.searchParams.set(key, value);
    }
  }

  const formData = new FormData();
  formData.append("file", file, file.name);

  const headers = {};
  if (csrfToken) headers["X-CSRF-Token"] = csrfToken;

  const response = await fetch(url.toString(), {
    method: "POST",
    headers,
    credentials: "include",
    body: formData,
  });

  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new ApiError("network_error", "Сервер вернул некорректный ответ", response.status);
  }

  if (!response.ok || payload.ok === false) {
    const err = payload.error ?? { code: "unknown_error", message: "Неизвестная ошибка" };
    throw new ApiError(err.code, err.message, response.status);
  }

  return payload.data;
}
