// =============================================================================
// App shell — sidebar navigation с "жидким" pill-индикатором + topbar
// =============================================================================

import { api } from "./api.js";
import { getLanguage, setLanguage, t, applyTranslations, onLanguageChange } from "./i18n.js";
import { hapticImpact } from "./telegram-webapp.js";

const ICONS = {
  dashboard:
    '<path d="M4 13h6V4H4v9zm0 7h6v-5H4v5zm10 0h6V11h-6v9zm0-16v5h6V4h-6z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" fill="none"/>',
  users:
    '<circle cx="9" cy="8" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M16 8.2a3 3 0 110 5.8M18.5 20c0-2.6-1.7-4.6-4-5.3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  groups:
    '<rect x="3" y="4" width="14" height="10" rx="3" stroke="currentColor" stroke-width="1.6"/><path d="M7 18.5h10a3 3 0 003-3V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  logs:
    '<rect x="5" y="3" width="14" height="18" rx="2.4" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  broadcast:
    '<path d="M3 11v2a2 2 0 002 2h1l2 5 2-1-1.5-4H12l6 3V6l-6 3H8L4.5 8" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" fill="none"/>',
  admins:
    '<circle cx="9" cy="8" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M16 5l1.2 2.4L20 8l-2 2 .4 2.6L16 11.4 13.6 12.6l.4-2.6-2-2 2.8-.4z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>',
  settings:
    '<circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.6"/><path d="M12 3v2.2M12 18.8V21M21 12h-2.2M5.2 12H3M18.4 5.6l-1.5 1.5M7.1 16.9l-1.5 1.5M18.4 18.4l-1.5-1.5M7.1 7.1L5.6 5.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  logout:
    '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
};

function navItemsForRole(admin) {
  const items = [
    { id: "dashboard", label: t("nav.dashboard"), icon: ICONS.dashboard },
    { id: "users", label: t("nav.users"), icon: ICONS.users },
    { id: "groups", label: t("nav.groups"), icon: ICONS.groups },
    { id: "logs", label: t("nav.logs"), icon: ICONS.logs },
    { id: "broadcast", label: t("nav.broadcast"), icon: ICONS.broadcast },
  ];

  if (admin.role === "owner") {
    items.push({ id: "admins", label: t("nav.admins"), icon: ICONS.admins });
  }
  items.push({ id: "settings", label: t("nav.settings"), icon: ICONS.settings });

  return items;
}

export function mountAppShell(container, { admin, onNavigate, onLogout }) {
  const items = navItemsForRole(admin);

  container.innerHTML = `
    <div class="app-shell">
      <nav class="glass sidebar" aria-label="Основная навигация">
        <div class="sidebar__brand">
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M12 2L4 6v6c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10V6l-8-4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
          </svg>
        </div>
        <div class="sidebar__nav" data-nav>
          <div class="sidebar__liquid" data-liquid></div>
          ${items
            .map(
              (item) => `
            <button class="sidebar__item" data-nav-item="${item.id}" title="${item.label}">
              <svg viewBox="0 0 24 24" fill="none">${item.icon}</svg>
              <span>${item.label}</span>
            </button>
          `
            )
            .join("")}
        </div>
        <div class="sidebar__spacer"></div>
        <button class="sidebar__logout" data-action="logout" title="${t("common.logout")}">
          <svg viewBox="0 0 24 24" fill="none">${ICONS.logout}</svg>
        </button>
      </nav>

      <main class="app-main">
        <header class="topbar">
          <h1 class="topbar__title" data-view-title></h1>
          <div class="topbar__actions">
            <div class="glass lang-switch" data-lang-switch>
              <button data-lang="ru">RU</button>
              <button data-lang="uz">UZ</button>
            </div>
          </div>
        </header>
        <div data-view-content></div>
      </main>
    </div>
  `;

  const nav = container.querySelector("[data-nav]");
  const liquid = container.querySelector("[data-liquid]");
  const viewTitle = container.querySelector("[data-view-title]");
  const viewContent = container.querySelector("[data-view-content]");
  const langButtons = [...container.querySelectorAll("[data-lang]")];

  function positionLiquid(activeBtn) {
    if (!activeBtn) return;
    const isMobile = window.matchMedia("(max-width: 760px)").matches;

    if (isMobile) {
      liquid.style.setProperty("--tab-w", `${activeBtn.offsetWidth}px`);
      liquid.style.transform = `translateX(${activeBtn.offsetLeft}px)`;
    } else {
      liquid.style.transform = `translateY(${activeBtn.offsetTop}px)`;
      liquid.style.height = `${activeBtn.offsetHeight}px`;
    }
  }

  function setActive(viewId) {
    const btn = nav.querySelector(`[data-nav-item="${viewId}"]`);
    nav.querySelectorAll(".sidebar__item").forEach((el) => el.classList.remove("is-active"));
    btn?.classList.add("is-active");
    positionLiquid(btn);

    const item = items.find((i) => i.id === viewId);
    viewTitle.textContent = item?.label ?? "";
  }

  function updateLangButtons() {
    const current = getLanguage();
    langButtons.forEach((btn) => btn.classList.toggle("is-active", btn.dataset.lang === current));
  }

  nav.querySelectorAll("[data-nav-item]").forEach((btn) => {
    btn.addEventListener("click", () => {
      hapticImpact("light");
      const viewId = btn.dataset.navItem;
      setActive(viewId);
      onNavigate(viewId, viewContent);
    });
  });

  langButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      setLanguage(btn.dataset.lang);
    });
  });

  onLanguageChange(() => {
    updateLangButtons();
    items.forEach((item, idx) => {
      item.label = [t("nav.dashboard"), t("nav.users"), t("nav.groups"), t("nav.logs"), t("nav.broadcast")][idx] ?? item.label;
    });
    applyTranslations(container);
  });

  container.querySelector('[data-action="logout"]').addEventListener("click", async () => {
    try {
      await api.post("/auth/logout");
    } finally {
      onLogout();
    }
  });

  window.addEventListener("resize", () => {
    const activeBtn = nav.querySelector(".sidebar__item.is-active");
    positionLiquid(activeBtn);
  });

  updateLangButtons();

  return {
    setActive,
    contentElement: viewContent,
  };
}
