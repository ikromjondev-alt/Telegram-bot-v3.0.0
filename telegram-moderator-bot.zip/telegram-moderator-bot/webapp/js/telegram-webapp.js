// =============================================================================
// Telegram WebApp SDK wrapper
// =============================================================================

export const tg = window.Telegram?.WebApp ?? null;

export function initTelegramWebApp() {
  if (!tg) return;

  tg.ready();
  tg.expand();

  try {
    tg.disableVerticalSwipes();
  } catch {
    /* метод может отсутствовать в старых клиентах — не критично */
  }

  tg.setHeaderColor("#000000");
  tg.setBackgroundColor("#000000");
}

/**
 * Сырая строка initData для передачи на backend для HMAC-валидации.
 * Backend НЕ доверяет содержимому — только серверной проверке подписи.
 */
export function getInitData() {
  return tg?.initData ?? "";
}

export function hapticImpact(style = "light") {
  try {
    tg?.HapticFeedback?.impactOccurred(style);
  } catch {
    /* нет haptics в браузере вне Telegram — молча игнорируем */
  }
}

export function hapticNotification(type = "success") {
  try {
    tg?.HapticFeedback?.notificationOccurred(type);
  } catch {
    /* noop */
  }
}

export function closeWebApp() {
  tg?.close();
}
