// =============================================================================
// Dashboard view
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";

const STAT_ICONS = {
  groups: '<path d="M4 4h9v9H4V4zm11 0h5v9h-5V4zM4 15h9v5H4v-5zm11 0h5v5h-5v-5z" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linejoin="round"/>',
  users: '<circle cx="9" cy="8" r="3" stroke="currentColor" stroke-width="1.6"/><path d="M3 19c0-3 2.7-5 6-5s6 2 6 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  deleted: '<path d="M5 7h14M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2m-9 0l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>',
  warns: '<path d="M12 4L3 20h18L12 4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" fill="none"/><path d="M12 10v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="17" r="0.9" fill="currentColor"/>',
  mutes: '<path d="M12 3a3 3 0 00-3 3v6a3 3 0 006 0V6a3 3 0 00-3-3z" stroke="currentColor" stroke-width="1.6"/><path d="M6 11a6 6 0 0012 0M12 17v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity="0.4"/><path d="M4 4l16 16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  bans: '<circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/><path d="M6 6l12 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  kicks: '<path d="M13 4l6 6-6 6M5 10h14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>',
};

function statCard({ icon, value, label, variant }) {
  return `
    <div class="glass glass--interactive card stat-card stat-card--${variant}">
      <div class="stat-card__icon"><svg viewBox="0 0 24 24" fill="none">${icon}</svg></div>
      <div class="stat-card__value">${value}</div>
      <div class="stat-card__label">${label}</div>
    </div>
  `;
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}д ${h}ч`;
  if (h > 0) return `${h}ч ${m}м`;
  return `${m}м`;
}

function skeletonMarkup() {
  return `
    <div class="stat-grid">
      ${Array.from({ length: 6 }).map(() => `<div class="skeleton" style="height:130px;"></div>`).join("")}
    </div>
    <div class="skeleton" style="height:180px; border-radius: var(--radius-lg);"></div>
  `;
}

export async function renderDashboard(container) {
  container.innerHTML = `<div class="view">${skeletonMarkup()}</div>`;

  let data;
  try {
    data = await api.get("/dashboard");
  } catch (err) {
    const message = err instanceof ApiError ? err.message : t("common.error");
    container.innerHTML = `
      <div class="view empty-state glass card">
        <div class="empty-state__title">${t("common.error")}</div>
        <p>${message}</p>
        <button class="btn btn--glass" data-action="retry">${t("common.retry")}</button>
      </div>
    `;
    container.querySelector('[data-action="retry"]').addEventListener("click", () => renderDashboard(container));
    return;
  }

  const bot = data.bot;
  const lastActivity = data.last_activity;

  container.innerHTML = `
    <div class="view">
      <div class="stat-grid">
        ${statCard({ icon: STAT_ICONS.groups, value: data.groups_count, label: t("dashboard.groups"), variant: "accent" })}
        ${statCard({ icon: STAT_ICONS.users, value: data.users_count, label: t("dashboard.users"), variant: "info" })}
        ${statCard({ icon: STAT_ICONS.deleted, value: data.deleted_messages_count, label: t("dashboard.deleted"), variant: "warning" })}
        ${statCard({ icon: STAT_ICONS.warns, value: data.warns_count, label: t("dashboard.warns"), variant: "warning" })}
        ${statCard({ icon: STAT_ICONS.mutes, value: data.mutes_count, label: t("dashboard.mutes"), variant: "info" })}
        ${statCard({ icon: STAT_ICONS.bans, value: data.bans_count, label: t("dashboard.bans"), variant: "danger" })}
      </div>

      <div class="dashboard-grid-2">
        <section class="glass card">
          <div class="card__header">
            <div>
              <div class="card__title">${t("dashboard.bot_status")}</div>
            </div>
            <span class="badge ${bot.online ? "badge--success" : "badge--danger"}">
              <span class="pulse-dot ${bot.online ? "" : "pulse-dot--offline"}" style="margin-right:2px;"></span>
              ${bot.online ? t("dashboard.online") : t("dashboard.offline")}
            </span>
          </div>
          <div class="bot-status-grid">
            <div class="bot-metric">
              <div class="bot-metric__value">${bot.ping_ms ?? "—"}${bot.ping_ms ? " ms" : ""}</div>
              <div class="bot-metric__label">${t("dashboard.ping")}</div>
            </div>
            <div class="bot-metric">
              <div class="bot-metric__value">${formatUptime(bot.uptime_seconds)}</div>
              <div class="bot-metric__label">${t("dashboard.uptime")}</div>
            </div>
            <div class="bot-metric">
              <div class="bot-metric__value">${bot.ram_mb} MB</div>
              <div class="bot-metric__label">${t("dashboard.ram")}</div>
            </div>
            <div class="bot-metric">
              <div class="bot-metric__value">${bot.cpu_percent}%</div>
              <div class="bot-metric__label">${t("dashboard.cpu")}</div>
            </div>
          </div>
        </section>

        <section class="glass card">
          <div class="card__header">
            <div class="card__title">${t("dashboard.last_activity")}</div>
          </div>
          ${
            lastActivity
              ? `
            <div class="activity-row">
              <div class="activity-row__meta">
                <span class="badge badge--neutral">${lastActivity.action_type}</span>
                <span class="activity-row__user">ID ${lastActivity.target_user_id}</span>
              </div>
              <span class="activity-row__time">${new Date(lastActivity.created_at).toLocaleString()}</span>
            </div>
          `
              : `<p style="color: var(--text-secondary); font-size: var(--fs-sm);">${t("dashboard.no_activity")}</p>`
          }
        </section>
      </div>
    </div>
  `;
}
