// =============================================================================
// Admins view — RBAC: список, добавление, изменение роли, удаление
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";
import { openModal, confirmModal } from "./../modal.js";
import { showToast } from "./../toast.js";

const ASSIGNABLE_ROLES = ["admin", "moderator", "viewer"];

function roleLabel(role) {
  return t(`admins.role.${role}`);
}

function roleBadgeVariant(role) {
  return { owner: "badge--success", admin: "badge--info", moderator: "badge--warning", viewer: "badge--neutral" }[role] ?? "badge--neutral";
}

function adminRow(admin, currentAdmin) {
  const isRoot = admin.is_root;
  const canManage = currentAdmin.role === "owner" && !isRoot;

  return `
    <div class="list-row" data-admin-row="${admin.telegram_id}" style="cursor: default;">
      <div class="list-row__avatar">${String(admin.telegram_id).slice(-2)}</div>
      <div class="list-row__main">
        <div class="list-row__title">
          ${admin.username ? "@" + admin.username : "ID " + admin.telegram_id}
          ${isRoot ? `<span class="badge badge--success" style="margin-left: 6px;">${t("admins.root_badge")}</span>` : ""}
        </div>
        <div class="list-row__subtitle">
          ${admin.last_login_at ? `${t("admins.last_login")}: ${new Date(admin.last_login_at).toLocaleString()}` : t("admins.never")}
        </div>
      </div>
      <div class="list-row__meta">
        ${
          canManage
            ? `
          <select class="input" style="width: auto; padding: 8px 12px; font-size: var(--fs-xs);" data-role-select>
            ${ASSIGNABLE_ROLES.map((r) => `<option value="${r}" ${r === admin.role ? "selected" : ""}>${roleLabel(r)}</option>`).join("")}
          </select>
          <button class="btn btn--danger btn--sm" data-action="remove">${t("common.delete")}</button>
        `
            : `<span class="badge ${roleBadgeVariant(admin.role)}">${roleLabel(admin.role)}</span>`
        }
      </div>
    </div>
  `;
}

function openAddAdminModal(onSaved) {
  openModal(
    `
      <h2 style="font-size: var(--fs-lg); margin-bottom: 16px;">${t("admins.add")}</h2>
      <div class="form-grid">
        <div class="field">
          <label class="field__label">${t("admins.id_label")}</label>
          <input class="input" type="text" inputmode="numeric" data-field="telegram_id" placeholder="123456789" />
        </div>
        <div class="field">
          <label class="field__label">${t("admins.role_label")}</label>
          <select class="input" data-field="role">
            ${ASSIGNABLE_ROLES.map((r) => `<option value="${r}">${roleLabel(r)}</option>`).join("")}
          </select>
        </div>
        <p class="auth-error" data-error></p>
        <div class="form-actions">
          <button class="btn btn--glass" data-cancel>${t("common.cancel")}</button>
          <button class="btn btn--primary" data-save>${t("common.add")}</button>
        </div>
      </div>
    `,
    {
      onMount(modal, close) {
        modal.querySelector("[data-cancel]").addEventListener("click", close);
        modal.querySelector("[data-save]").addEventListener("click", async () => {
          const errorEl = modal.querySelector("[data-error]");
          const telegramId = modal.querySelector('[data-field="telegram_id"]').value.trim();
          const role = modal.querySelector('[data-field="role"]').value;

          if (!/^\d{4,15}$/.test(telegramId)) {
            errorEl.textContent = t("auth.error.generic");
            return;
          }

          try {
            await api.post("/admins", { telegram_id: telegramId, role });
            showToast(t("common.saved"));
            onSaved();
            close();
          } catch (err) {
            errorEl.textContent = err instanceof ApiError ? err.message : t("common.error");
          }
        });
      },
    }
  );
}

export async function renderAdmins(container, currentAdmin) {
  container.innerHTML = `
    <div class="view">
      ${
        currentAdmin.role === "owner"
          ? `<div class="toolbar"><div></div><button class="btn btn--primary" data-action="add">${t("admins.add")}</button></div>`
          : ""
      }
      <div class="glass card" style="padding: var(--space-2) var(--space-5);">
        <div class="list" data-list><div class="skeleton" style="height: 260px;"></div></div>
      </div>
    </div>
  `;

  const list = container.querySelector("[data-list]");

  async function load() {
    let admins;
    try {
      admins = await api.get("/admins");
    } catch (err) {
      list.innerHTML = `<p style="color: var(--color-danger); padding: var(--space-4) 0;">${
        err instanceof ApiError ? err.message : t("common.error")
      }</p>`;
      return;
    }

    list.innerHTML = admins.map((a) => adminRow(a, currentAdmin)).join("");

    list.querySelectorAll("[data-admin-row]").forEach((row) => {
      const telegramId = row.dataset.adminRow;

      row.querySelector("[data-role-select]")?.addEventListener("change", async (event) => {
        try {
          await api.patch(`/admins/${telegramId}`, { role: event.target.value });
          showToast(t("common.saved"));
        } catch (err) {
          showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
          load();
        }
      });

      row.querySelector('[data-action="remove"]')?.addEventListener("click", () => {
        confirmModal({
          title: t("admins.remove_confirm_title"),
          message: t("admins.remove_confirm_message"),
          confirmLabel: t("common.delete"),
          async onConfirm() {
            try {
              await api.delete(`/admins/${telegramId}`);
              showToast(t("common.saved"));
              load();
            } catch (err) {
              showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
            }
          },
        });
      });
    });
  }

  container.querySelector('[data-action="add"]')?.addEventListener("click", () => openAddAdminModal(load));

  await load();
}
