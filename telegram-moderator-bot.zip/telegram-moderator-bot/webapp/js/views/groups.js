// =============================================================================
// Groups view — список подключённых групп, настройка, отключение
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";
import { confirmModal } from "./../modal.js";
import { showToast } from "./../toast.js";
import { openGroupSettingsModal } from "./group-settings-modal.js";

function initials(title) {
  return (title || "?").trim().slice(0, 2).toUpperCase();
}

function groupRow(group) {
  return `
    <div class="list-row" data-group-row="${group.chat_id}">
      <div class="list-row__avatar">${initials(group.title)}</div>
      <div class="list-row__main">
        <div class="list-row__title">${group.title}</div>
        <div class="list-row__subtitle">
          ${group.username ? "@" + group.username + " · " : ""}${group.members_count} ${t("groups.members")}
        </div>
      </div>
      <div class="list-row__meta">
        <button class="btn btn--glass btn--sm" data-action="configure">${t("groups.configure")}</button>
        <button class="btn btn--danger btn--sm" data-action="disconnect">${t("groups.disconnect")}</button>
      </div>
    </div>
  `;
}

export async function renderGroups(container) {
  container.innerHTML = `
    <div class="view">
      <div class="glass card" style="padding: var(--space-2) var(--space-5);">
        <div class="list" data-list><div class="skeleton" style="height: 300px;"></div></div>
      </div>
    </div>
  `;

  const list = container.querySelector("[data-list]");

  async function load() {
    let groups;
    try {
      groups = await api.get("/groups");
    } catch (err) {
      list.innerHTML = `<p style="color: var(--color-danger); padding: var(--space-4) 0;">${
        err instanceof ApiError ? err.message : t("common.error")
      }</p>`;
      return;
    }

    if (!groups.length) {
      list.innerHTML = `<div class="empty-state"><div class="empty-state__title">${t("groups.title")}</div><p>${t(
        "groups.empty"
      )}</p></div>`;
      return;
    }

    list.innerHTML = groups.map(groupRow).join("");

    list.querySelectorAll("[data-group-row]").forEach((row) => {
      const chatId = row.dataset.groupRow;

      row.querySelector('[data-action="configure"]').addEventListener("click", async (event) => {
        event.stopPropagation();
        try {
          const fullGroup = await api.get(`/groups/${chatId}`);
          openGroupSettingsModal(fullGroup, load);
        } catch (err) {
          showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
        }
      });

      row.querySelector('[data-action="disconnect"]').addEventListener("click", (event) => {
        event.stopPropagation();
        confirmModal({
          title: t("groups.disconnect_confirm_title"),
          message: t("groups.disconnect_confirm_message"),
          confirmLabel: t("groups.disconnect"),
          danger: true,
          async onConfirm() {
            try {
              await api.delete(`/groups/${chatId}`);
              showToast(t("common.saved"));
              load();
            } catch (err) {
              showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
            }
          },
        });
      });
    });
  }

  await load();
}
