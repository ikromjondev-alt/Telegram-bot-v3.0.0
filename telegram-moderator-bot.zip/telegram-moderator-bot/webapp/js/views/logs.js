// =============================================================================
// Logs view — аудит-журнал и журнал модерации
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";

const PAGE_SIZE = 40;

const AUDIT_VARIANT = {
  login_success: "badge--success",
  login_failed: "badge--danger",
  admin_removed: "badge--danger",
  error: "badge--danger",
  admin_added: "badge--success",
  group_added: "badge--success",
  group_removed: "badge--danger",
};

const MODERATION_VARIANT = {
  ban: "badge--danger",
  kick: "badge--danger",
  mute: "badge--warning",
  warn: "badge--warning",
  unmute: "badge--success",
  unban: "badge--success",
  clear: "badge--neutral",
  delete_message: "badge--neutral",
  auto_antispam: "badge--danger",
  auto_antiflood: "badge--warning",
};

function auditRow(entry) {
  return `
    <div class="activity-row">
      <div class="activity-row__meta">
        <span class="badge ${AUDIT_VARIANT[entry.event_type] ?? "badge--neutral"}">${entry.event_type}</span>
        <span style="font-size: var(--fs-sm);">${entry.description}</span>
        <span class="activity-row__user">
          ${entry.actor_id ? `${t("logs.actor")}: ${entry.actor_id}` : t("logs.system")}
          ${entry.ip_address ? " · " + entry.ip_address : ""}
        </span>
      </div>
      <span class="activity-row__time">${new Date(entry.created_at).toLocaleString()}</span>
    </div>
  `;
}

function moderationRow(entry) {
  return `
    <div class="activity-row">
      <div class="activity-row__meta">
        <span class="badge ${MODERATION_VARIANT[entry.action_type] ?? "badge--neutral"}">${entry.action_type}</span>
        <span class="activity-row__user">→ ID ${entry.target_user_id} · группа ${entry.group_id}</span>
        ${entry.reason ? `<span style="font-size: var(--fs-xs); color: var(--text-secondary);">${entry.reason}</span>` : ""}
      </div>
      <span class="activity-row__time">${new Date(entry.created_at).toLocaleString()}</span>
    </div>
  `;
}

export async function renderLogs(container) {
  let activeTab = "audit";
  let offset = 0;

  container.innerHTML = `
    <div class="view">
      <div class="glass tabs" data-tabs>
        <button class="is-active" data-tab="audit">${t("logs.tab_audit")}</button>
        <button data-tab="moderation">${t("logs.tab_moderation")}</button>
      </div>
      <div class="glass card">
        <div class="list" data-list><div class="skeleton" style="height: 320px;"></div></div>
      </div>
      <div class="pagination" data-pagination></div>
    </div>
  `;

  const list = container.querySelector("[data-list]");
  const pagination = container.querySelector("[data-pagination]");
  const tabs = container.querySelector("[data-tabs]");

  async function load(reset) {
    if (reset) {
      offset = 0;
      list.innerHTML = `<div class="skeleton" style="height: 320px;"></div>`;
    }

    const path = activeTab === "audit" ? "/logs" : "/logs/moderation";
    const renderRow = activeTab === "audit" ? auditRow : moderationRow;

    let entries;
    try {
      entries = await api.get(path, { limit: PAGE_SIZE, offset });
    } catch (err) {
      list.innerHTML = `<p style="color: var(--color-danger); padding: var(--space-4) 0;">${
        err instanceof ApiError ? err.message : t("common.error")
      }</p>`;
      return;
    }

    const rowsHtml = entries.map(renderRow).join("");
    if (reset) {
      list.innerHTML = entries.length ? rowsHtml : `<div class="empty-state">${t("common.empty")}</div>`;
    } else {
      list.insertAdjacentHTML("beforeend", rowsHtml);
    }

    offset += entries.length;
    pagination.innerHTML =
      entries.length === PAGE_SIZE
        ? `<button class="btn btn--glass" data-load-more>${t("common.load_more")}</button>`
        : "";
    pagination.querySelector("[data-load-more]")?.addEventListener("click", () => load(false));
  }

  tabs.querySelectorAll("[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.dataset.tab === activeTab) return;
      tabs.querySelectorAll("[data-tab]").forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      activeTab = btn.dataset.tab;
      load(true);
    });
  });

  await load(true);
}
