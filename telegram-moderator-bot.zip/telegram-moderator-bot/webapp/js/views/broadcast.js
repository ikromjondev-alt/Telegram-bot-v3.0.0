// =============================================================================
// Broadcast view — композер рассылки с предпросмотром и статистикой
// =============================================================================

import { api, ApiError, uploadFile } from "./../api.js";
import { t } from "./../i18n.js";
import { showToast } from "./../toast.js";

function getContentTypes() {
  return [
    { value: "text", label: t("broadcast.text") },
    { value: "photo", label: t("broadcast.photo") },
    { value: "video", label: t("broadcast.video") },
    { value: "document", label: t("broadcast.document") },
    { value: "animation", label: t("broadcast.animation") },
  ];
}

const STATUS_BADGE = {
  draft: "badge--neutral",
  queued: "badge--info",
  sending: "badge--warning",
  completed: "badge--success",
  failed: "badge--danger",
};

function historyRow(b) {
  const progress = b.target_count ? Math.round(((b.sent_count + b.failed_count) / b.target_count) * 100) : 0;
  return `
    <div class="glass card" style="margin-bottom: var(--space-3);">
      <div class="card__header">
        <div>
          <div class="card__title">#${b.id} · ${t("broadcast." + b.content_type)}</div>
          <div class="card__subtitle">${b.text ? b.text.slice(0, 60) : ""}</div>
        </div>
        <span class="badge ${STATUS_BADGE[b.status] ?? "badge--neutral"}">${t("broadcast.status." + b.status)}</span>
      </div>
      <div class="progress-bar" style="margin-bottom: 10px;">
        <div class="progress-bar__fill" style="width: ${progress}%;"></div>
      </div>
      <div style="display:flex; gap: var(--space-4); font-size: var(--fs-xs); color: var(--text-secondary);">
        <span>${t("broadcast.target")}: ${b.target_count}</span>
        <span style="color: var(--color-accent);">${t("broadcast.sent")}: ${b.sent_count}</span>
        <span style="color: var(--color-danger);">${t("broadcast.failed")}: ${b.failed_count}</span>
      </div>
      ${
        b.status === "queued"
          ? `<button class="btn btn--primary btn--sm" data-send="${b.id}" style="margin-top: 12px;">${t("broadcast.send")}</button>`
          : ""
      }
    </div>
  `;
}

function composerMarkup() {
  const contentTypes = getContentTypes();
  return `
    <div class="glass card" style="margin-bottom: var(--space-5);">
      <div class="card__header"><div class="card__title">${t("broadcast.new")}</div></div>

      <div class="form-grid">
        <div class="field">
          <label class="field__label">${t("broadcast.type")}</label>
          <select class="input" data-field="content_type">
            ${contentTypes.map((c) => `<option value="${c.value}">${c.label}</option>`).join("")}
          </select>
        </div>

        <div class="field" data-media-upload hidden>
          <label class="field__label" data-upload-label></label>
          <div class="file-drop" data-drop-zone>
            <span data-drop-text>${t("broadcast.upload_hint")}</span>
            <img class="file-drop__preview" data-preview hidden />
          </div>
          <input type="file" data-file-input hidden />
        </div>

        <div class="field">
          <label class="field__label">${t("broadcast.text_label")}</label>
          <textarea class="input" rows="4" data-field="text" style="resize: vertical;"></textarea>
        </div>

        <div class="field">
          <label class="field__label">${t("broadcast.buttons")}</label>
          <div class="button-row-editor" data-buttons></div>
          <button class="btn btn--glass btn--sm" type="button" data-action="add-button" style="align-self: flex-start; margin-top: 8px;">
            + ${t("broadcast.add_button")}
          </button>
        </div>

        <p class="auth-error" data-error></p>

        <button class="btn btn--primary" data-action="create" style="width: 100%;">${t("broadcast.create")}</button>
      </div>
    </div>
  `;
}

function buttonRowMarkup() {
  return `
    <div class="button-row-editor__item" data-button-item>
      <input class="input" placeholder="Текст кнопки" data-btn-text />
      <input class="input" placeholder="https://…" data-btn-url />
      <button class="btn btn--icon btn--ghost" type="button" data-remove-button>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
      </button>
    </div>
  `;
}

export async function renderBroadcast(container) {
  container.innerHTML = `
    <div class="view">
      ${composerMarkup()}
      <div class="card__header" style="padding: 0 var(--space-2); margin-bottom: var(--space-3);">
        <div class="card__title">${t("broadcast.title")}</div>
      </div>
      <div data-history><div class="skeleton" style="height: 200px;"></div></div>
    </div>
  `;

  const contentTypeSelect = container.querySelector('[data-field="content_type"]');
  const contentTypes = getContentTypes();
  const mediaUpload = container.querySelector("[data-media-upload]");
  const uploadLabel = container.querySelector("[data-upload-label]");
  const dropZone = container.querySelector("[data-drop-zone]");
  const dropText = container.querySelector("[data-drop-text]");
  const preview = container.querySelector("[data-preview]");
  const fileInput = container.querySelector("[data-file-input]");
  const buttonsWrap = container.querySelector("[data-buttons]");
  const errorEl = container.querySelector("[data-error]");
  const historyEl = container.querySelector("[data-history]");

  let uploadedFileId = null;

  function syncMediaVisibility() {
    const isMedia = contentTypeSelect.value !== "text";
    mediaUpload.hidden = !isMedia;
    if (isMedia) {
      uploadLabel.textContent = contentTypes.find((c) => c.value === contentTypeSelect.value)?.label ?? "";
    }
    uploadedFileId = null;
    preview.hidden = true;
    dropText.textContent = t("broadcast.upload_hint");
  }

  contentTypeSelect.addEventListener("change", syncMediaVisibility);
  syncMediaVisibility();

  dropZone.addEventListener("click", () => fileInput.click());
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("is-dragover");
  });
  dropZone.addEventListener("dragleave", () => dropZone.classList.remove("is-dragover"));
  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("is-dragover");
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener("change", () => {
    if (fileInput.files[0]) handleFile(fileInput.files[0]);
  });

  async function handleFile(file) {
    dropText.textContent = "⏳ " + file.name;
    try {
      const data = await uploadFile("/broadcast/upload", file, { content_type: contentTypeSelect.value });
      uploadedFileId = data.file_id;
      dropText.textContent = "✅ " + file.name;
      if (file.type.startsWith("image/")) {
        preview.src = URL.createObjectURL(file);
        preview.hidden = false;
      }
    } catch (err) {
      dropText.textContent = t("broadcast.upload_hint");
      showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
    }
  }

  function addButtonRow() {
    buttonsWrap.insertAdjacentHTML("beforeend", buttonRowMarkup());
    buttonsWrap.lastElementChild.querySelector("[data-remove-button]").addEventListener("click", (e) => {
      e.currentTarget.closest("[data-button-item]").remove();
    });
  }
  container.querySelector('[data-action="add-button"]').addEventListener("click", addButtonRow);

  function collectButtons() {
    const rows = [...buttonsWrap.querySelectorAll("[data-button-item]")];
    const buttons = rows
      .map((row) => ({
        text: row.querySelector("[data-btn-text]").value.trim(),
        url: row.querySelector("[data-btn-url]").value.trim(),
      }))
      .filter((b) => b.text && b.url)
      .map((b) => [b]); // одна кнопка на строку
    return buttons.length ? buttons : null;
  }

  async function loadHistory() {
    let items;
    try {
      items = await api.get("/broadcast", { limit: 30 });
    } catch (err) {
      historyEl.innerHTML = `<p style="color: var(--color-danger);">${err instanceof ApiError ? err.message : t("common.error")}</p>`;
      return;
    }

    historyEl.innerHTML = items.length
      ? items.map(historyRow).join("")
      : `<div class="empty-state glass card">${t("broadcast.empty")}</div>`;

    historyEl.querySelectorAll("[data-send]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        btn.disabled = true;
        btn.textContent = t("broadcast.status.sending");
        try {
          await api.post(`/broadcast/${btn.dataset.send}/send`);
          showToast(t("common.saved"));
          setTimeout(loadHistory, 1200);
        } catch (err) {
          showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
          btn.disabled = false;
        }
      });
    });
  }

  container.querySelector('[data-action="create"]').addEventListener("click", async () => {
    errorEl.textContent = "";
    const contentType = contentTypeSelect.value;
    const text = container.querySelector('[data-field="text"]').value.trim();

    if (contentType === "text" && !text) {
      errorEl.textContent = t("broadcast.text_label");
      return;
    }
    if (contentType !== "text" && !uploadedFileId) {
      errorEl.textContent = t("broadcast.upload_hint");
      return;
    }

    const createBtn = container.querySelector('[data-action="create"]');
    createBtn.disabled = true;

    try {
      await api.post("/broadcast", {
        content_type: contentType,
        text: text || null,
        file_id: uploadedFileId,
        buttons: collectButtons(),
      });
      showToast(t("common.saved"));
      container.querySelector('[data-field="text"]').value = "";
      buttonsWrap.innerHTML = "";
      syncMediaVisibility();
      loadHistory();
    } catch (err) {
      errorEl.textContent = err instanceof ApiError ? err.message : t("common.error");
    } finally {
      createBtn.disabled = false;
    }
  });

  await loadHistory();
}
