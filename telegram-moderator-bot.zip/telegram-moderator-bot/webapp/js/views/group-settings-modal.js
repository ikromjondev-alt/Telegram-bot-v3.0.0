// =============================================================================
// Group settings modal — общий компонент для Groups и Settings views
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";
import { openModal } from "./../modal.js";
import { showToast } from "./../toast.js";

function switchMarkup(field, checked) {
  return `
    <button class="switch" role="switch" aria-checked="${checked}" data-toggle="${field}">
      <span class="switch__thumb"></span>
    </button>
  `;
}

export function openGroupSettingsModal(group, onSaved) {
  const s = group.settings;

  openModal(
    `
      <h2 style="font-size: var(--fs-lg); margin-bottom: 4px;">${group.title}</h2>
      <p style="color: var(--text-secondary); font-size: var(--fs-sm); margin-bottom: 16px;">${t("groups.settings_title")}</p>

      <div class="form-grid">
        <div class="form-row-2">
          <div class="field">
            <label class="field__label">${t("groups.mute_duration")}</label>
            <input class="input" type="number" min="1" max="43200" value="${s.mute_duration_minutes}" data-field="mute_duration_minutes" />
          </div>
          <div class="field">
            <label class="field__label">${t("groups.warn_limit")}</label>
            <input class="input" type="number" min="1" max="20" value="${s.warn_limit}" data-field="warn_limit" />
          </div>
        </div>
        <div class="form-row-2">
          <div class="field">
            <label class="field__label">${t("groups.flood_limit")}</label>
            <input class="input" type="number" min="1" max="100" value="${s.flood_limit}" data-field="flood_limit" />
          </div>
          <div class="field">
            <label class="field__label">${t("groups.flood_window")}</label>
            <input class="input" type="number" min="1" max="600" value="${s.flood_window_seconds}" data-field="flood_window_seconds" />
          </div>
        </div>

        <hr class="divider" style="margin: 4px 0;" />

        <div class="settings-row">
          <span class="settings-row__label">${t("groups.antispam")}</span>
          ${switchMarkup("antispam_enabled", s.antispam_enabled)}
        </div>
        <div class="settings-row">
          <span class="settings-row__label">${t("groups.antiflood")}</span>
          ${switchMarkup("antiflood_enabled", s.antiflood_enabled)}
        </div>
        <div class="settings-row">
          <span class="settings-row__label">${t("groups.autodelete")}</span>
          ${switchMarkup("auto_delete_service_messages", s.auto_delete_service_messages)}
        </div>
        <div class="settings-row">
          <span class="settings-row__label">${t("groups.logs_enabled")}</span>
          ${switchMarkup("logs_enabled", s.logs_enabled)}
        </div>
        <div class="settings-row">
          <span class="settings-row__label">${t("groups.notifications_enabled")}</span>
          ${switchMarkup("notifications_enabled", s.notifications_enabled)}
        </div>

        <div class="field">
          <label class="field__label">${t("groups.language")}</label>
          <select class="input" data-field="language">
            <option value="ru" ${s.language === "ru" ? "selected" : ""}>Русский</option>
            <option value="uz" ${s.language === "uz" ? "selected" : ""}>O'zbekcha</option>
          </select>
        </div>

        <div class="form-actions">
          <button class="btn btn--glass" data-cancel>${t("common.cancel")}</button>
          <button class="btn btn--primary" data-save>${t("common.save")}</button>
        </div>
      </div>
    `,
    {
      maxWidth: "440px",
      onMount(modal, close) {
        modal.querySelectorAll("[data-toggle]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const isChecked = btn.getAttribute("aria-checked") === "true";
            btn.setAttribute("aria-checked", String(!isChecked));
          });
        });

        modal.querySelector("[data-cancel]").addEventListener("click", close);

        modal.querySelector("[data-save]").addEventListener("click", async () => {
          const saveBtn = modal.querySelector("[data-save]");
          saveBtn.disabled = true;

          const payload = {
            mute_duration_minutes: Number(modal.querySelector('[data-field="mute_duration_minutes"]').value),
            warn_limit: Number(modal.querySelector('[data-field="warn_limit"]').value),
            flood_limit: Number(modal.querySelector('[data-field="flood_limit"]').value),
            flood_window_seconds: Number(modal.querySelector('[data-field="flood_window_seconds"]').value),
            antispam_enabled: modal.querySelector('[data-toggle="antispam_enabled"]').getAttribute("aria-checked") === "true",
            antiflood_enabled: modal.querySelector('[data-toggle="antiflood_enabled"]').getAttribute("aria-checked") === "true",
            auto_delete_service_messages:
              modal.querySelector('[data-toggle="auto_delete_service_messages"]').getAttribute("aria-checked") === "true",
            logs_enabled: modal.querySelector('[data-toggle="logs_enabled"]').getAttribute("aria-checked") === "true",
            notifications_enabled:
              modal.querySelector('[data-toggle="notifications_enabled"]').getAttribute("aria-checked") === "true",
            language: modal.querySelector('[data-field="language"]').value,
          };

          try {
            await api.patch(`/groups/${group.chat_id}/settings`, payload);
            showToast(t("common.saved"));
            onSaved?.();
            close();
          } catch (err) {
            showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
            saveBtn.disabled = false;
          }
        });
      },
    }
  );
}
