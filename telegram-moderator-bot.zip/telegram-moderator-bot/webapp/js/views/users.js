// =============================================================================
// Users view — просмотр, поиск, история модерации
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";
import { openModal } from "./../modal.js";

const PAGE_SIZE = 30;

function initials(user) {
  const source = user.first_name || user.username || String(user.telegram_id);
  return source.slice(0, 2).toUpperCase();
}

function userRow(user) {
  const name = [user.first_name, user.last_name].filter(Boolean).join(" ") || user.username || `ID ${user.telegram_id}`;
  return `
    <div class="list-row" data-user-row="${user.telegram_id}">
      <div class="list-row__avatar">${initials(user)}</div>
      <div class="list-row__main">
        <div class="list-row__title">${name}</div>
        <div class="list-row__subtitle">${user.username ? "@" + user.username : "ID " + user.telegram_id}</div>
      </div>
      <div class="list-row__meta">
        ${user.is_globally_banned ? `<span class="badge badge--danger">${t("users.banned")}</span>` : ""}
      </div>
    </div>
  `;
}

const ACTION_VARIANT = {
  ban: "badge--danger",
  kick: "badge--danger",
  mute: "badge--warning",
  warn: "badge--warning",
  unmute: "badge--success",
  unban: "badge--success",
  auto_antispam: "badge--danger",
  auto_antiflood: "badge--warning",
};

async function openUserHistory(user) {
  openModal(
    `
      <h2 style="font-size: var(--fs-lg); margin-bottom: 4px;">${user.username ? "@" + user.username : "ID " + user.telegram_id}</h2>
      <p style="color: var(--text-secondary); font-size: var(--fs-sm); margin-bottom: 16px;">${t("users.history")}</p>
      <div data-history-content><div class="skeleton" style="height: 160px;"></div></div>
    `,
    {
      maxWidth: "480px",
      async onMount(modal) {
        const content = modal.querySelector("[data-history-content]");
        try {
          const history = await api.get(`/users/${user.telegram_id}/history`);
          if (!history.length) {
            content.innerHTML = `<p style="color: var(--text-secondary); font-size: var(--fs-sm);">${t("users.no_history")}</p>`;
            return;
          }
          content.innerHTML = `
            <div class="list">
              ${history
                .map(
                  (item) => `
                <div class="activity-row">
                  <div class="activity-row__meta">
                    <span class="badge ${ACTION_VARIANT[item.action_type] ?? "badge--neutral"}">${item.action_type}</span>
                    ${item.reason ? `<span class="activity-row__time">${item.reason}</span>` : ""}
                  </div>
                  <span class="activity-row__time">${new Date(item.created_at).toLocaleString()}</span>
                </div>
              `
                )
                .join("")}
            </div>
          `;
        } catch (err) {
          content.innerHTML = `<p style="color: var(--color-danger); font-size: var(--fs-sm);">${t("common.error")}</p>`;
        }
      },
    }
  );
}

export async function renderUsers(container) {
  let offset = 0;
  let total = 0;
  let search = "";
  let debounceTimer = null;

  container.innerHTML = `
    <div class="view">
      <div class="toolbar">
        <input class="input" type="search" placeholder="${t("users.search_placeholder")}" data-search />
      </div>
      <div class="glass card" style="padding: var(--space-2) var(--space-5);">
        <div class="list" data-list><div class="skeleton" style="height: 300px;"></div></div>
      </div>
      <div class="pagination" data-pagination></div>
    </div>
  `;

  const list = container.querySelector("[data-list]");
  const pagination = container.querySelector("[data-pagination]");
  const searchInput = container.querySelector("[data-search]");

  async function load(reset) {
    if (reset) {
      offset = 0;
      list.innerHTML = `<div class="skeleton" style="height: 300px;"></div>`;
    }

    let data;
    try {
      data = await api.get("/users", { search, limit: PAGE_SIZE, offset });
    } catch (err) {
      list.innerHTML = `<p style="color: var(--color-danger); padding: var(--space-4) 0;">${
        err instanceof ApiError ? err.message : t("common.error")
      }</p>`;
      return;
    }

    total = data.total;

    const rowsHtml = data.items.map(userRow).join("");
    if (reset) {
      list.innerHTML = data.items.length ? rowsHtml : `<div class="empty-state">${t("common.empty")}</div>`;
    } else {
      list.insertAdjacentHTML("beforeend", rowsHtml);
    }

    list.querySelectorAll("[data-user-row]").forEach((row) => {
      row.addEventListener("click", () => {
        const user = data.items.find((u) => String(u.telegram_id) === row.dataset.userRow);
        if (user) openUserHistory(user);
      });
    });

    offset += data.items.length;
    renderPagination();
  }

  function renderPagination() {
    if (offset >= total) {
      pagination.innerHTML = "";
      return;
    }
    pagination.innerHTML = `<button class="btn btn--glass" data-load-more>${t("common.load_more")} (${offset}/${total})</button>`;
    pagination.querySelector("[data-load-more]").addEventListener("click", () => load(false));
  }

  searchInput.addEventListener("input", (event) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      search = event.target.value.trim();
      load(true);
    }, 350);
  });

  await load(true);
}
