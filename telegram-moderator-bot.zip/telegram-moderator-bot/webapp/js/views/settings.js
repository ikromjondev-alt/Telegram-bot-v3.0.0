// =============================================================================
// Settings view — параметры модерации (время мута, warn, флуд, автоудаление,
// логи, язык, уведомления) по каждой подключённой группе
// =============================================================================

import { api, ApiError } from "./../api.js";
import { t } from "./../i18n.js";
import { showToast } from "./../toast.js";
import { openGroupSettingsModal } from "./group-settings-modal.js";

function settingsRow(group) {
  return `
    <div class="list-row" data-group-row="${group.chat_id}">
      <div class="list-row__main">
        <div class="list-row__title">${group.title}</div>
        <div class="list-row__subtitle">${group.username ? "@" + group.username : "ID " + group.chat_id}</div>
      </div>
      <div class="list-row__meta">
        <button class="btn btn--glass btn--sm" data-action="configure">${t("groups.configure")}</button>
      </div>
    </div>
  `;
}

export async function renderSettings(container) {
  container.innerHTML = `
    <div class="view">
      <div class="glass card" style="margin-bottom: var(--space-4);">
        <div class="card__title">${t("settings.title")}</div>
        <p class="card__subtitle">${t("settings.subtitle")}</p>
      </div>
      <div class="glass card" style="padding: var(--space-2) var(--space-5);">
        <div class="list" data-list><div class="skeleton" style="height: 220px;"></div></div>
      </div>
    </div>
  `;

  const list = container.querySelector("[data-list]");

  let groups;
  try {
    groups = await api.get("/groups");
  } catch (err) {
    list.innerHTML = `<p style="color: var(--color-danger); padding: var(--space-4) 0;">${
      err instanceof ApiError ? err.message : t("common.error")
    }</p>`;
    return;
  }

  if (!groups.length) {
    list.innerHTML = `<div class="empty-state">${t("groups.empty")}</div>`;
    return;
  }

  list.innerHTML = groups.map(settingsRow).join("");

  list.querySelectorAll("[data-group-row]").forEach((row) => {
    const chatId = row.dataset.groupRow;
    row.querySelector('[data-action="configure"]').addEventListener("click", async () => {
      try {
        const fullGroup = await api.get(`/groups/${chatId}`);
        openGroupSettingsModal(fullGroup);
      } catch (err) {
        showToast(err instanceof ApiError ? err.message : t("common.error"), { type: "error" });
      }
    });
  });
}
