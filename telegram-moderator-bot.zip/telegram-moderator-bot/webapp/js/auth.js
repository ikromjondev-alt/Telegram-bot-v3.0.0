// =============================================================================
// Auth screen — двухшаговая авторизация (Telegram ID -> код подтверждения)
// =============================================================================

import { api, ApiError, setCsrfToken } from "./api.js";
import { t, applyTranslations } from "./i18n.js";
import { getInitData, hapticNotification } from "./telegram-webapp.js";

const CODE_TTL_SECONDS = 120;

function markup() {
  return `
    <div class="auth-screen">
      <div class="glass glass--heavy auth-card">
        <div class="auth-mark">
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M12 2L4 6v6c0 5 3.4 8.6 8 10 4.6-1.4 8-5 8-10V6l-8-4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
            <path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>

        <div class="auth-steps">
          <section class="auth-step auth-step-enter" data-step="id">
            <h1 class="auth-title" data-i18n="auth.title">${t("auth.title")}</h1>
            <p class="auth-subtitle" data-i18n="auth.subtitle">${t("auth.subtitle")}</p>

            <form data-form="request-code" novalidate>
              <div class="field">
                <label class="field__label" for="telegram-id" data-i18n="auth.id_label">${t("auth.id_label")}</label>
                <input
                  id="telegram-id"
                  class="input"
                  type="text"
                  inputmode="numeric"
                  autocomplete="off"
                  data-i18n-placeholder="auth.id_placeholder"
                  placeholder="${t("auth.id_placeholder")}"
                  required
                />
              </div>
              <p class="auth-error" data-error="id"></p>
              <button class="btn btn--primary" type="submit" style="width:100%; margin-top: 8px;" data-submit>
                <span data-i18n="auth.send_code">${t("auth.send_code")}</span>
              </button>
            </form>
          </section>

          <section class="auth-step" data-step="code" hidden>
            <h1 class="auth-title" data-i18n="auth.code_title">${t("auth.code_title")}</h1>
            <p class="auth-subtitle" data-i18n="auth.code_subtitle">${t("auth.code_subtitle")}</p>

            <form data-form="verify-code" novalidate>
              <div class="field">
                <input
                  id="auth-code"
                  class="input input--code"
                  type="text"
                  inputmode="numeric"
                  maxlength="6"
                  autocomplete="one-time-code"
                  placeholder="••••••"
                  required
                />
              </div>
              <p class="auth-code-hint" data-i18n="auth.code_hint">${t("auth.code_hint")}</p>
              <p class="auth-error" data-error="code"></p>

              <div class="auth-timer">
                <svg class="auth-timer__ring" viewBox="0 0 20 20">
                  <circle class="track" cx="10" cy="10" r="8"></circle>
                  <circle class="progress" cx="10" cy="10" r="8" data-ring></circle>
                </svg>
                <span data-timer-text></span>
              </div>

              <button class="btn btn--primary" type="submit" style="width:100%; margin-top: 16px;" data-submit>
                <span data-i18n="auth.verify">${t("auth.verify")}</span>
              </button>
              <button class="btn btn--ghost auth-back" type="button" data-action="back" style="width:100%; margin-top: 8px;">
                <span data-i18n="auth.back">${t("auth.back")}</span>
              </button>
            </form>
          </section>
        </div>

        <p class="auth-footer" data-i18n="auth.footer">${t("auth.footer")}</p>
      </div>
    </div>
  `;
}

export function mountAuthScreen(container, onSuccess) {
  container.innerHTML = markup();
  applyTranslations(container);

  const stepId = container.querySelector('[data-step="id"]');
  const stepCode = container.querySelector('[data-step="code"]');
  const idInput = container.querySelector("#telegram-id");
  const codeInput = container.querySelector("#auth-code");
  const idError = container.querySelector('[data-error="id"]');
  const codeError = container.querySelector('[data-error="code"]');
  const ring = container.querySelector("[data-ring]");
  const timerText = container.querySelector("[data-timer-text]");

  const RING_CIRCUMFERENCE = 2 * Math.PI * 8;
  ring.style.strokeDasharray = `${RING_CIRCUMFERENCE}`;

  let telegramId = null;
  let timerInterval = null;

  function startCountdown(seconds) {
    clearInterval(timerInterval);
    let remaining = seconds;

    const tick = () => {
      const fraction = remaining / CODE_TTL_SECONDS;
      ring.style.strokeDashoffset = `${RING_CIRCUMFERENCE * (1 - fraction)}`;
      timerText.textContent = `${Math.max(remaining, 0)}s`;

      if (remaining <= 0) {
        clearInterval(timerInterval);
        codeError.textContent = t("auth.expired");
      }
      remaining -= 1;
    };

    tick();
    timerInterval = setInterval(tick, 1000);
  }

  function goToStep(step) {
    if (step === "code") {
      stepId.hidden = true;
      stepCode.hidden = false;
      stepCode.classList.add("auth-step-enter");
      codeInput.value = "";
      codeError.textContent = "";
      setTimeout(() => codeInput.focus(), 260);
      startCountdown(CODE_TTL_SECONDS);
    } else {
      clearInterval(timerInterval);
      stepCode.hidden = true;
      stepId.hidden = false;
      stepId.classList.add("auth-step-enter");
    }
  }

  function setLoading(form, loading) {
    const btn = form.querySelector("[data-submit]");
    btn.disabled = loading;
    btn.style.opacity = loading ? "0.7" : "1";
  }

  function mapError(err) {
    if (err instanceof ApiError) {
      if (err.code === "forbidden") return t("auth.error.forbidden");
      if (err.code === "invalid_auth_code") return t("auth.error.invalid_code");
      if (err.code === "auth_code_expired") return t("auth.expired");
    }
    return t("auth.error.generic");
  }

  container.querySelector('[data-form="request-code"]').addEventListener("submit", async (event) => {
    event.preventDefault();
    idError.textContent = "";

    const raw = idInput.value.trim();
    if (!/^\d{4,15}$/.test(raw)) {
      idError.textContent = t("auth.error.generic");
      return;
    }

    telegramId = raw;
    const form = event.currentTarget;
    setLoading(form, true);

    try {
      await api.post("/auth/request-code", {
        telegram_id: telegramId,
        init_data: getInitData(),
      });
      goToStep("code");
    } catch (err) {
      idError.textContent = mapError(err);
    } finally {
      setLoading(form, false);
    }
  });

  container.querySelector('[data-form="verify-code"]').addEventListener("submit", async (event) => {
    event.preventDefault();
    codeError.textContent = "";

    const code = codeInput.value.trim();
    if (!/^\d{4,8}$/.test(code)) {
      codeError.textContent = t("auth.error.invalid_code");
      return;
    }

    const form = event.currentTarget;
    setLoading(form, true);

    try {
      const data = await api.post("/auth/verify-code", {
        telegram_id: telegramId,
        code,
        init_data: getInitData(),
      });
      setCsrfToken(data.csrf_token);
      hapticNotification("success");
      onSuccess(data.admin);
    } catch (err) {
      codeError.textContent = mapError(err);
      hapticNotification("error");
    } finally {
      setLoading(form, false);
    }
  });

  container.querySelector('[data-action="back"]').addEventListener("click", () => goToStep("id"));

  setTimeout(() => idInput.focus(), 300);
}
